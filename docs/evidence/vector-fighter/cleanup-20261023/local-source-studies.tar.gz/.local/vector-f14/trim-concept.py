import json,shutil,numpy as np
from pathlib import Path
from scipy.spatial import cKDTree
src=Path('.local/vector-f14/shotgun-clearance-concept');out=Path('.local/vector-f14/shotgun-trim-concept');out.mkdir(exist_ok=True)
part=next(d for d in json.loads(Path('.local/vector-f14/surface/Shotgun-components.json').read_text()) if d['id']==88);tree=cKDTree(part['verts']);text=[];changed=0;name=''
for line in (src/'Shotgun-actual-mesh.obj').read_text().splitlines():
 if line.startswith('o '):name=line[2:]
 if line.startswith('v ') and 'hands' not in name:
  p=np.array(list(map(float,line.split()[1:])));dist,idx=tree.query(p)
  if dist<.00002:
   p[0]=.0095+(p[0]-.0095)*(.0455/.153);p[2]=-.07+(p[2]+.07)*(.15/.28);line='v '+' '.join(str(x) for x in p);changed+=1
 text.append(line)
(out/'Shotgun-actual-mesh.obj').write_text('\n'.join(text)+'\n');shutil.copyfile(src/'Shotgun-axes.csv',out/'Shotgun-axes.csv');print('Concept only:',changed,'weapon vertices; hands fixed')
