import bpy,sys,math
from pathlib import Path
from mathutils import Matrix,Vector,Quaternion
root=Path('.local/vector-f14/study-7');out=Path('.local/vector-f14/source12-preview');out.mkdir(exist_ok=True)
bpy.ops.wm.open_mainfile(filepath='scripts/vector_fighter/f14-hand-anatomy.blend')
rig=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');obj=bpy.data.objects['VECTOR articulated gloves']
C=Matrix(((-1,0,0),(0,0,1),(0,-1,0)));scale=3.12
for weapon in ['Rifle','Shotgun','RocketLauncher','Cutter']:
 bones={}
 for line in (root/(weapon+'-vector-armored-hands-skin.txt')).read_text().splitlines():
  a=line.split()
  if a[0]=='b':bones[a[1]]=(Vector(tuple(map(float,a[2:5]))),Quaternion((float(a[8]),*map(float,a[5:8]))).to_matrix())
 transforms={}
 for b in rig.data.bones:
  if b.name in bones:
   p,r=bones[b.name];transforms[b.name]=(p,r@(C@b.matrix_local.to_3x3()@C.inverted()).inverted(),C@b.head_local)
 lines=['o vector-armored-hands']
 for v in obj.data.vertices:
  result=Vector();total=0
  for g in v.groups:
   name=obj.vertex_groups[g.group].name
   if name in transforms:
    p,r,h=transforms[name];result+=(p+r@(C@v.co-h)*scale)*g.weight;total+=g.weight
  assert total>.99,total
  lines.append('v '+' '.join(map(str,result)))
 for f in obj.data.polygons:lines.append('f '+' '.join(str(i+1) for i in f.vertices))
 # Reuse unchanged captured equipment triangles, with OBJ index remapping.
 src=(root/(weapon+'-actual-mesh.obj')).read_text().splitlines();oldverts=[];parts={};name=''
 for line in src:
  a=line.split()
  if a[0]=='o':name=a[1];parts[name]=[]
  elif a[0]=='v':oldverts.append(line)
  elif a[0]=='f':parts[name].append([int(i)-1 for i in a[1:]])
 offset=len(obj.data.vertices)
 for name,faces in parts.items():
  if 'hands' in name:continue
  used=sorted(set(i for f in faces for i in f));mapping={i:offset+j+1 for j,i in enumerate(used)};lines.append('o '+name);lines.extend(oldverts[i] for i in used)
  lines.extend('f '+' '.join(str(mapping[i]) for i in f) for f in faces);offset+=len(used)
 (out/(weapon+'-actual-mesh.obj')).write_text('\n'.join(lines)+'\n');(out/(weapon+'-axes.csv')).write_bytes((root/(weapon+'-axes.csv')).read_bytes())
print('POSED SOURCE PREVIEW COMPLETE')
