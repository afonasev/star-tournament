import json,csv,numpy as np
from scipy.interpolate import RegularGridInterpolator
from pathlib import Path
grid=json.loads(Path('.local/vector-f14/surface/grid.json').read_text())
for weapon in ['Rifle','Shotgun','RocketLauncher','Cutter']:
 field=np.fromfile('.local/vector-f14/surface/'+weapon+'.bin',dtype=np.float32).reshape([a[2] for a in grid]);sdf=RegularGridInterpolator([np.linspace(*a) for a in grid],field,bounds_error=False,fill_value=.4)
 axes={a['name']:a for a in csv.DictReader(open('.local/vector-f14/study-3/'+weapon+'-axes.csv'))}
 print(weapon)
 for name,a in axes.items():
  if name.endswith('Proximal'):
   p=np.array([float(a[k]) for k in ['px','py','pz']]);print(name, 'root',np.round(p,3),'signed distance',np.round(sdf([p]),4))
