import csv,json,sys,numpy as np,shutil
from pathlib import Path
from scipy.spatial.transform import Rotation as R
from scipy.spatial import cKDTree
root=Path('.local/vector-f14/study-3');out=Path(sys.argv[1]);out.mkdir(exist_ok=True)
fit=dict(line.split('=') for line in (out/'grip.txt').read_text().splitlines());oldvalues=dict(line.split('=') for line in Path('.local/vector-f14/fit-next/grip.txt').read_text().splitlines())
def rot(a,v):return R.from_rotvec(np.asarray(a)*np.deg2rad(v)).as_matrix()
for wi,weapon in enumerate(['Rifle','Shotgun','RocketLauncher','Cutter']):
 axes={a['name']:a for a in csv.DictReader((root/(weapon+'-axes.csv')).open())};verts=[];weights=[];bones={}
 for line in (root/(weapon+'-vector-armored-hands-skin.txt')).read_text().splitlines():
  a=line.split()
  if a[0]=='b':bones[a[1]]=(np.array(list(map(float,a[2:5]))),R.from_quat(list(map(float,a[5:9]))).as_matrix())
  elif a[0]=='v':verts.append(list(map(float,a[1:4])));weights.append({k:float(v) for k,v in (t.split(':') for t in a[4:])})
 original=np.array(verts);posed=original.copy()
 for side in ['Left','Right']:
  for di,digit in enumerate(['Thumb','Index','Middle','Ring','Little']):
   keys=['Proximal','Intermediate','Distal','Spread'];prefix=f'grip.{weapon}.{side.lower()}.{digit}.';old=np.array([float(oldvalues[prefix+k]) for k in keys]);x=np.array([float(fit[prefix+k]) for k in keys]);names=[side+digit+k for k in keys[:3]];data=[bones[n] for n in names];curl=[np.array([float(axes[n]['c'+a]) for a in 'xyz']) for n in names];spread=np.array([float(axes[names[0]]['s'+a]) for a in 'xyz']);common=(0 if di==0 else (7 if wi<2 else 32)) if side=='Left' else (7.5 if di==0 else 15);total=old[0]+common;delta=x-old;ps=[data[0][0]];rs=[data[0][1]@rot(curl[0],total)@rot(spread,delta[3])@rot(curl[0],-total-delta[0])]
   for j in [1,2]:
    p,r=data[j];prev=data[j-1];ps.append(ps[-1]+rs[-1]@prev[1].T@(p-prev[0]));rs.append(rs[-1]@prev[1].T@r@rot(curl[j],-delta[j]))
   for j,(p,r) in enumerate(data):
    ws=np.array([w.get(names[j],0) for w in weights]);new=(original-p)@(rs[j]@r.T).T+ps[j];posed+=(new-original)*ws[:,None]
 text=[];i=0;name='';tree=cKDTree(original)
 for line in (root/(weapon+'-actual-mesh.obj')).read_text().splitlines():
  if line.startswith('o '):name=line[2:]
  if line.startswith('v ') and 'hands' in name:
   point=np.array(list(map(float,line.split()[1:])));dist,idx=tree.query(point)
   if dist<1e-6:line='v '+' '.join(str(v) for v in posed[idx]);i+=1
  text.append(line)
 print(weapon,i,len(posed));(out/(weapon+'-actual-mesh.obj')).write_text('\n'.join(text)+'\n');shutil.copyfile(root/(weapon+'-axes.csv'),out/(weapon+'-axes.csv'))
