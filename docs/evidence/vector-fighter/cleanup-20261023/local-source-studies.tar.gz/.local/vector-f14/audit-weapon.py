import json,struct,subprocess
from pathlib import Path
import numpy as np
exec(Path('.local/vector-f14/compare_glb.py').read_text().split('report={}')[0])
p='unity/Assets/StarTournament/Art/trooper-arms-animated.glb';a,ab=read(subprocess.check_output(['git','show','cdddf3717ec750dbb0865046674550bb96f2de36:'+p]));b,bb=read(Path(p).read_bytes());out=[]
ma=next(n['mesh'] for n in a['nodes'] if n.get('name')=='weapon:joined');mb=next(n['mesh'] for n in b['nodes'] if n.get('name')=='weapon:joined')
for ap,bp in zip(a['meshes'][ma]['primitives'],b['meshes'][mb]['primitives']):
 assert accessor(a,ab,ap['indices'])==accessor(b,bb,bp['indices']);av=np.frombuffer(accessor(a,ab,ap['attributes']['POSITION']),np.float32).reshape(-1,3);bv=np.frombuffer(accessor(b,bb,bp['attributes']['POSITION']),np.float32).reshape(-1,3);assert av.shape==bv.shape;changed=np.any(np.abs(av-bv)>1e-6,axis=1)
 out.append({'material':a['materials'][ap['material']]['name'],'vertices':len(av),'changed':int(changed.sum()),'old_bounds':None if not changed.any() else [av[changed].min(0).tolist(),av[changed].max(0).tolist()],'new_bounds':None if not changed.any() else [bv[changed].min(0).tolist(),bv[changed].max(0).tolist()]})
assert sum(r['changed'] for r in out)==115,out
Path('.local/vector-f14/weapon-change-audit.json').write_text(json.dumps(out,indent=2));print([(r['material'],r['changed']) for r in out])
