from pathlib import Path
import csv,json,numpy as np
from scipy.spatial.transform import Rotation as R
from scipy.optimize import least_squares
from scipy.interpolate import RegularGridInterpolator
root=Path('.local/vector-f14/study-3');out=Path('.local/vector-f14/anatomic-fit');out.mkdir(exist_ok=True)
oldvalues=dict(line.split('=') for line in Path('.local/vector-f14/fit-next/grip.txt').read_text().splitlines())
grid=json.loads(Path('.local/vector-f14/surface/grid.json').read_text());report={};lines=[]
def rot(a,v):return R.from_rotvec(np.asarray(a)*np.deg2rad(v)).as_matrix()
for wi,weapon in enumerate(['Rifle','Shotgun','RocketLauncher','Cutter']):
 field=np.fromfile('.local/vector-f14/surface/'+weapon+'.bin',dtype=np.float32).reshape([a[2] for a in grid]);sdf=RegularGridInterpolator([np.linspace(*a) for a in grid],field,bounds_error=False,fill_value=.4)
 axes={a['name']:a for a in csv.DictReader((root/(weapon+'-axes.csv')).open())};verts=[];weights=[];bones={};report[weapon]={}
 for line in (root/(weapon+'-vector-armored-hands-skin.txt')).read_text().splitlines():
  a=line.split()
  if a[0]=='b':bones[a[1]]=(np.array(list(map(float,a[2:5]))),R.from_quat(list(map(float,a[5:9]))).as_matrix())
  elif a[0]=='v':verts.append(list(map(float,a[1:4])));weights.append({k:float(v) for k,v in (t.split(':') for t in a[4:])})
 verts=np.array(verts)
 for side in ['Left','Right']:
  for di,digit in enumerate(['Thumb','Index','Middle','Ring','Little']):
   prefix=f'grip.{weapon}.{side.lower()}.{digit}.';keys=['Proximal','Intermediate','Distal','Spread'];old=np.array([float(oldvalues[prefix+k]) for k in keys]);names=[side+digit+k for k in keys[:3]];data=[bones[n] for n in names]
   ids=np.array([i for i,w in enumerate(weights) if sum(w.get(n,0) for n in names)>.5]);_,unique=np.unique(np.round(verts[ids],4),axis=0,return_index=True);ids=ids[unique][::3];original=verts[ids];ws=np.array([[weights[i].get(n,0) for n in names] for i in ids]);fixed=1-ws.sum(axis=1)
   curl=[np.array([float(axes[n]['c'+a]) for a in 'xyz']) for n in names];spread=np.array([float(axes[names[0]]['s'+a]) for a in 'xyz']);common=(0 if di==0 else (7 if wi<2 else 32)) if side=='Left' else (7.5 if di==0 else 15);total=old[0]+common
   def model(x):
    delta=x-old;ps=[data[0][0]];rs=[data[0][1]@rot(curl[0],total)@rot(spread,delta[3])@rot(curl[0],-total-delta[0])]
    for j in [1,2]:
     p,r=data[j];prev=data[j-1];ps.append(ps[-1]+rs[-1]@prev[1].T@(p-prev[0]));rs.append(rs[-1]@prev[1].T@r@rot(curl[j],-delta[j]))
    posed=original*fixed[:,None]
    for j,(p,r) in enumerate(data):posed+=ws[:,j,None]*((original-p)@(rs[j]@r.T).T+ps[j])
    # Distal direction follows the authored terminal bone direction.
    end=data[2][1]@data[1][1].T@(data[2][0]-data[1][0]);ps.append(ps[-1]+rs[-1]@data[2][1].T@end*.85)
    return np.array(ps),posed
   base=data[0][0];target=[]
   if side=='Right':
    y=base[1]
    if digit=='Thumb':
     target=np.array([[.045,-.16,-.225],[-.015,-.16,-.145],[-.055,-.16,-.085]])
    elif weapon=='Shotgun':
     ys=[0,-.13,-.20,-.27,-.30];yy=ys[di]
     target=np.array([[.19 if di<4 else .13,(y+yy)/2,-.11],[.195,yy,-.025],[.19,yy,.045]])
    else:
     yy=max(y,-.29 if weapon!='Rifle' else -.335)
     z=.045 if weapon=='Rifle' else (.04 if weapon=='RocketLauncher' else .049)
     xx=.055 if weapon=='Rifle' else .039
     target=np.array([[xx+.030,(y+yy)/2,z+.025],[-.005,yy,z+.040],[-xx-.023,yy,z-.005]])
   elif wi<2:
    z=base[2]
    if digit=='Thumb':
     target=np.array([[-.145,-.09,z+.005],[-.135,.005,z+.005],[-.12,.07,z+.005]])
    else:
     coords=([(.10,-.14),(.17,-.13),(.17,-.045),(.155,-.035)] if wi==1 else [(.10,-.115),(.155,-.065),(.155,-.015),(.14,-.005)])[di-1]
     second=([(.125,-.06),(.14,-.045),(.11,.01),(.09,.015)] if wi==1 else [(.145,-.045),(.12,.01),(.085,.025),(.075,.02)])[di-1]
     tip=([(.115,.005),(.095,.005),(.055,-.005),(.035,-.005)] if wi==1 else [(.125,.02),(.065,.02),(.035,-.005),(.025,-.01)])[di-1]
     target=np.array([[*coords,z],[*second,z],[*tip,z]])
   else:
    z=.49 if wi==2 else .415;y=base[1]
    if digit=='Thumb':target=np.array([[-.12,-.105,z-.15],[-.06,-.115,z-.07],[.005,-.12,z-.065]])
    else:
     yy=max(y,-.27 if wi==2 else -.29);target=np.array([[-.055,(y+yy)/2,z+.115],[.025,yy,z+.085],[.06,yy,z+.015]])
   def residual(x):
    ps,p=model(x);dist=sdf(p);vs=np.diff(ps,axis=0);vs/=np.linalg.norm(vs,axis=1)[:,None];angles=np.rad2deg(np.arccos(np.clip(np.sum(vs[:-1]*vs[1:],axis=1),-1,1)));bends=np.cross(vs[:-1],vs[1:]);res=list(np.maximum(-dist-.001,0)*3/np.sqrt(len(dist)))
    res.extend(((ps[1:]-target)*5).ravel())
    res.extend(np.maximum(angles-[105,80],0)*.008);res.append(max(0,-np.dot(bends[0],bends[1]))*.7)
    if di:res.append(np.dot(np.cross(vs[0],vs[1]),vs[2])*.2)
    res.extend((x-old)*.00002)
    return res
   bounds=([-90,-90,-90,-70],[90,90,90,70]);best=None
   for seed in [old,np.zeros(4),np.array([-70,15,0,old[3]]),np.array([-60,35,15,0])] :
    fit=least_squares(residual,np.clip(seed,*bounds),bounds=bounds,max_nfev=100,diff_step=.001)
    if best is None or np.linalg.norm(fit.fun)<np.linalg.norm(best.fun):best=fit
   x=np.round(best.x);ps,p=model(x);dist=sdf(p);report[weapon][side+digit]={'angles':x.tolist(),'min':float(dist.min()),'penetration':float(np.mean(dist<-.003)),'joints':ps.tolist()}
   print(weapon,side,digit,x,'min',round(float(dist.min()),4),'penetration',round(float(np.mean(dist<-.003)),3),flush=True)
   for k,v in zip(keys,x):lines.append(prefix+k+'='+str(int(v)))
(out/'grip.txt').write_text('\n'.join(lines)+'\n');(out/'report.json').write_text(json.dumps(report,indent=2))
