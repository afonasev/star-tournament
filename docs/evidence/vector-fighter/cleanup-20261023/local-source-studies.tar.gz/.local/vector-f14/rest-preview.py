import bpy,math
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath='scripts/vector_fighter/f14-hand-anatomy.blend')
rig=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');glove=bpy.data.objects['VECTOR articulated gloves']
for o in bpy.context.scene.objects:
 if o.type=='MESH':o.hide_render=o!=glove
for t in rig.animation_data.nla_tracks:t.mute=True
rig.animation_data.action=None
for b in rig.pose.bones:b.matrix_basis.identity()
w=rig.data.bones['LeftHand'].head_local;tip=rig.data.bones['LeftMiddleDistal'].tail_local;center=w.lerp(tip,.5);n=Vector((1,0,1)).normalized()
bpy.ops.object.camera_add(location=center-n*.5);cam=bpy.context.object;cam.rotation_euler=(center-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=.30;bpy.context.scene.camera=cam
for off,power,size in [((-0.4,-.3,.6),100,.4),((.3,.2,.3),80,.3)]:
 bpy.ops.object.light_add(type='AREA',location=center+Vector(off));light=bpy.context.object;light.data.energy=power;light.data.shape='DISK';light.data.size=size;light.rotation_euler=(center-light.location).to_track_quat('-Z','Y').to_euler()
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=16;scene.render.resolution_x=900;scene.render.resolution_y=900;scene.render.resolution_percentage=100;scene.world=bpy.data.worlds.new('Preview');scene.world.color=(.2,.2,.2);scene.render.filepath='.local/vector-f14/rest-preview.png';bpy.ops.render.render(write_still=True)
