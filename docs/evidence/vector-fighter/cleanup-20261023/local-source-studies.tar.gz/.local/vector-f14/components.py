import numpy as np,json
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from pathlib import Path
for w in ['Rifle','Shotgun','RocketLauncher','Cutter']:
 vs=[];fs=[];name=''
 for line in Path('.local/vector-f14/study-3/'+w+'-actual-mesh.obj').read_text().splitlines():
  a=line.split()
  if a[0]=='o':name=a[1]
  elif a[0]=='v':vs.append(list(map(float,a[1:])))
  elif a[0]=='f' and 'hands' not in name:fs.append([int(i)-1 for i in a[1:]])
 vs=np.array(vs);fs=np.array(fs);ids=np.unique(fs);points,rev=np.unique(np.round(vs[ids],5),axis=0,return_inverse=True);mapper=np.zeros(len(vs),int);mapper[ids]=rev;tris=mapper[fs];a=tris.ravel();b=tris[:,[1,2,0]].ravel();n,labels=connected_components(coo_matrix((np.ones(len(a)),(a,b)),shape=(len(points),len(points))),directed=False);out=[]
 for i in range(n):
  p=points[labels==i];lo=p.min(axis=0);hi=p.max(axis=0)
  if hi[1]>-.5 and lo[1]<-.07 and hi[2]>-.4 and lo[2]<.7 and np.prod(hi-lo)>.00001:
   out.append({'id':i,'min':lo.tolist(),'max':hi.tolist(),'verts':p.tolist()})
 Path('.local/vector-f14/surface/'+w+'-components.json').write_text(json.dumps(out))
 print(w,[(x['id'],x['min'],x['max']) for x in out],flush=True)
