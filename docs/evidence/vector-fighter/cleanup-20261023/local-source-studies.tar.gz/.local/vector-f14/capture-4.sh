#!/bin/sh
set -eu
mkdir -p .local/vector-f14/study-4
STAR_TOURNAMENT_GRIP_OVERRIDES="$PWD/.local/vector-f14/surface-fit/grip.txt" STAR_TOURNAMENT_GRIP_FACTORY=1 STAR_TOURNAMENT_GRIP_MESH=1 STAR_TOURNAMENT_WALK_EVIDENCE="$PWD/.local/vector-f14/study-4" STAR_TOURNAMENT_QA_LAB_HISTORY="$PWD/.local/vector-f14/study-4/history.json" UNITY_RUN_MODE=shared unity/tools.sh editor -batchmode -noaudio -muted -runTests -testPlatform PlayMode -testFilter 'FirstPersonStepsStaySmoothAndIndependentInTheRenderedScene' -testResults "$PWD/.local/vector-f14/study-4/results.xml" -logFile "$PWD/.local/vector-f14/study-4/editor.log" > .local/vector-f14/study-4/runner.log 2>&1
