import bpy,bmesh
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath='scripts/vector_fighter/f11-fps-forms.blend');o=bpy.data.objects['weapon:joined'];print('WEAPON MATRIX',o.matrix_world)
bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.000001);remaining=set(bm.verts)
while remaining:
 todo=[remaining.pop()];part=[]
 while todo:
  v=todo.pop();part.append(v)
  for e in v.link_edges:
   other=e.other_vert(v)
   if other in remaining:remaining.remove(other);todo.append(other)
 lo=Vector([min(v.co[i] for v in part) for i in range(3)]);hi=Vector([max(v.co[i] for v in part) for i in range(3)]);size=hi-lo
 if abs(size.x-.153)<.003:print('MATCH',len(part),list(lo),list(hi))
