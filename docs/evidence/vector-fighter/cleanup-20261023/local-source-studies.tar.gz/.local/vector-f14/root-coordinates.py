import bpy
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath='scripts/vector_fighter/f11-fps-forms.blend')
r=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE')
w=r.data.bones['LeftHand'].head_local;e=sum((r.data.bones['Left'+d+'Proximal'].head_local for d in ['Index','Middle','Ring','Little']),Vector())/4;a=(e-w).normalized();n=Vector((1,0,1)).normalized();n=(n-a*n.dot(a)).normalized();l=n.cross(a).normalized();length=(e-w).length
print('PALM',length)
for d in ['Thumb','Index','Middle','Ring','Little']:
 b=r.data.bones['Left'+d+'Proximal'];p=b.head_local-w
 print(d,'long',p.dot(a)/length,'lat',p.dot(l),'normal',p.dot(n),'length',b.length)
