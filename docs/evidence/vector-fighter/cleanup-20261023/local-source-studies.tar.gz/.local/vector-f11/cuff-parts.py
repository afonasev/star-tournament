import bpy,bmesh
from mathutils import Vector
from collections import Counter
bpy.ops.wm.open_mainfile(filepath='scripts/vector_fighter/f9-fp-detail.blend');r=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');o=bpy.data.objects['VECTOR articulated gloves'];bm=bmesh.new();bm.from_mesh(o.data);left=set(bm.verts);counts=Counter()
while left:
 todo=[left.pop()];part=[]
 while todo:
  v=todo.pop();part.append(v)
  for e in v.link_edges:
   n=e.other_vert(v)
   if n in left:left.remove(n);todo.append(n)
 if len(part)>1000:continue
 c=sum((v.co for v in part),Vector())/len(part);side='Left' if c.x>0 else 'Right';a=r.data.bones[side+'LowerArm'].head_local;b=r.data.bones[side+'Hand'].head_local;s=(c-b).dot((b-a).normalized())
 if s<.04:counts[(len(part),o.data.materials[next(iter(part[0].link_faces)).material_index].name,round(s,3))]+=1
print(counts)
