import bpy,math
from pathlib import Path
from mathutils import Vector,Quaternion
ROOT=Path.cwd();OUT=ROOT/'.local/vector-f11'
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'scripts/vector_fighter/f11-fps-forms.blend'))
rig=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');rig.animation_data_clear()
for p in rig.pose.bones:p.matrix_basis.identity()
# Same display blue as the game; neutral runtime source remains untouched.
for m in bpy.data.materials:
    if m.name.startswith('vector-fighter-identity-forearm') or m.name=='vector-ceramic.001':
        bs=next(n for n in m.node_tree.nodes if n.type=='BSDF_PRINCIPLED');base=bs.inputs['Base Color']
        if base.is_linked:
            old=base.links[0].from_socket;mix=m.node_tree.nodes.new('ShaderNodeMixRGB');mix.blend_type='MULTIPLY';mix.inputs[0].default_value=1;mix.inputs[2].default_value=(.07,.55,1,1)
            m.node_tree.links.new(old,mix.inputs[1]);m.node_tree.links.new(mix.outputs[0],base)
        else:base.default_value=(.025,.18,.32,1)
for o in bpy.context.scene.objects:
    if o.type=='MESH':o.hide_render=not ('LeftLowerArm' in o.name or 'gloves' in o.name or 'UpperArm fabric' in o.name)
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=48;s.cycles.use_denoising=True
s.render.resolution_x=1400;s.render.resolution_y=900;s.render.resolution_percentage=100
s.world=bpy.data.worlds.new('F10 studio');s.world.use_nodes=True
wn=s.world.node_tree.nodes;wl=s.world.node_tree.links;wn.clear()
bg=wn.new('ShaderNodeBackground');wo=wn.new('ShaderNodeOutputWorld');wl.new(bg.outputs[0],wo.inputs[0]);bg.inputs[0].default_value=(.055,.065,.08,1);bg.inputs[1].default_value=.5
s.view_settings.view_transform='AgX'
center=Vector((.535,.055,1.045))
for offset,power,size in [((.2,-.8,.7),9,.65),((.5,.4,.3),6.5,.5),((-.5,-.2,.2),4.5,.4)]:
    bpy.ops.object.light_add(type='AREA',location=center+Vector(offset));o=bpy.context.object;o.data.energy=power;o.data.size=size;o.rotation_euler=(center-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=center+Vector((.45,-.9,.45)))
cam=bpy.context.object;s.camera=cam;cam.rotation_euler=(center-cam.location).to_track_quat('-Z','Y').to_euler();cam.rotation_euler=(cam.rotation_euler.to_quaternion()@Quaternion((0,0,1),math.radians(-45))).to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=.55
s.render.filepath=str(OUT/'surface-diagnostic.png')
bpy.context.preferences.filepaths.save_version=0;bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'surface-diagnostic.blend'),compress=True);bpy.ops.render.render(write_still=True)
