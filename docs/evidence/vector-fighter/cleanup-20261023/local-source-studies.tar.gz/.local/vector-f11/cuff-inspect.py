import bpy,bmesh
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath='scripts/vector_fighter/f9-fp-detail.blend');r=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');o=bpy.data.objects['VECTOR articulated gloves'];bm=bmesh.new();bm.from_mesh(o.data)
a=r.data.bones['LeftLowerArm'].head_local;b=r.data.bones['LeftHand'].head_local;axis=(b-a).normalized()
vs=[v for v in bm.verts if v.co.x>0 and v.is_boundary and (v.co-b).dot(axis)<.05]
print('CUFF_BOUNDARY',len(vs), sorted(round((v.co-b).dot(axis),4) for v in vs))
