import bpy,bmesh,json
from collections import Counter
bpy.ops.wm.open_mainfile(filepath='scripts/vector_fighter/f9-fp-detail.blend')
r=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE')
for o in bpy.context.scene.objects:
 if o.type!='MESH' or not any(s in o.name for s in ['gloves','LowerArm','UpperArm fabric']):continue
 print('OBJECT',o.name,len(o.data.vertices),list(o.matrix_world))
 print('MATS',[m.name for m in o.data.materials])
 bm=bmesh.new();bm.from_mesh(o.data);bm.verts.ensure_lookup_table();bm.verts.index_update();left=set(bm.verts);parts=[]
 while left:
  todo=[left.pop()];part=[]
  while todo:
   v=todo.pop();part.append(v)
   for e in v.link_edges:
    n=e.other_vert(v)
    if n in left:left.remove(n);todo.append(n)
  parts.append(part)
 print('ISLANDS',Counter(len(p) for p in parts))
 for p in parts:
  if len(p)<100:continue
  ids=[v.index for v in p];c=sum((v.co for v in p),__import__('mathutils').Vector())/len(p)
  mats=Counter(o.data.materials[f.material_index].name for v in p for f in v.link_faces)
  print('PART',len(p),list(c),mats, 'bounds',[(min(v.co[i] for v in p),max(v.co[i] for v in p)) for i in range(3)])
 bm.free()
for n in ['LeftLowerArm','LeftHand','LeftMiddleProximal']:print('BONE',n,list(r.data.bones[n].head_local),list(r.data.bones[n].tail_local))
