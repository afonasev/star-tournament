"""F13: reshape existing gloves around the unchanged F12 hand skeleton.
Palm thickness, thumb web and finger pads are edited in the bind surface;
existing material layers follow the same continuous deformation. No arm edits.
"""
import bpy,bmesh,math,json,importlib.util
from pathlib import Path
from mathutils import Vector
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'.local/vector-f13';OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'scripts/vector_fighter/f11-fps-forms.blend'))
rig=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');o=bpy.data.objects['VECTOR articulated gloves'];count=len(bpy.context.scene.objects)
frames={}
for side,sign in [('Left',1),('Right',-1)]:
 wrist=rig.data.bones[side+'Hand'].head_local.copy();end=sum((rig.data.bones[side+d+'Proximal'].head_local for d in ['Index','Middle','Ring','Little']),Vector())/4
 axis=(end-wrist).normalized();normal=Vector((sign,0,1)).normalized();normal=(normal-axis*normal.dot(axis)).normalized();lateral=normal.cross(axis).normalized()
 frames[side]=(wrist,axis,normal,lateral,(end-wrist).length)
def smooth(a,b,x):
 t=max(0,min(1,(x-a)/(b-a)));return t*t*(3-2*t)
changed=0
for v in o.data.vertices:
 p=v.co.copy();side='Left' if p.x>0 else 'Right';w,axis,n,lat,length=frames[side];rel=p-w;t=rel.dot(axis)/length;depth=rel.dot(n)
 # Preserve the seated cuff and knuckle line; reduce the padded spherical palm
 # to a flatter metacarpal volume with a gradual thenar/hypothenar transition.
 palm=smooth(.02,.22,t)*(1-smooth(.72,1.04,t))
 p-=n*depth*.36*palm
 # Taper the palm heel into the unchanged cuff instead of an abrupt bulge.
 heel=smooth(.02,.20,t)*(1-smooth(.32,.72,t))
 p-=lat*rel.dot(lat)*.14*heel
 # Follow the nearest finger chain only after its root web. The palmar contact
 # half stays in place; flatten the dorsal padding, preserving gripping pads.
 chains=[]
 for digit in ['Thumb','Index','Middle','Ring','Little']:
  chain=[rig.data.bones[side+digit+s] for s in ['Proximal','Intermediate','Distal']]
  for b in chain:
   d=b.tail_local-b.head_local;u=max(0,min(1,(v.co-b.head_local).dot(d)/d.length_squared));q=b.head_local+d*u
   chains.append(((v.co-q).length,digit,b,q,d.normalized()))
 _,digit,b,q,d=min(chains,key=lambda item:item[0]);root=rig.data.bones[side+digit+'Proximal'];advance=(v.co-root.head_local).dot((root.tail_local-root.head_local).normalized())
 if advance>0:
  fade=smooth(0,.018,advance);radial=v.co-q;dn=n-d*n.dot(d);dn.normalize();dorsal=radial.dot(dn)
  if dorsal>0:p-=dn*dorsal*.20*fade
  # A less swollen thumb shaft, while retaining its pad and bone positions.
  if digit=='Thumb':p-=(radial-dn*dorsal)*.10*fade
 if (p-v.co).length>1e-7:changed+=1
 v.co=p
o.data.update()
# Smooth only the continuous cloth shells. Existing armor/seam islands stay
# as distinct manufactured layers and keep their original material identities.
bm=bmesh.new();bm.from_mesh(o.data);bm.verts.ensure_lookup_table();bm.verts.index_update();remaining=set(bm.verts);cloth=[]
while remaining:
 todo=[remaining.pop()];part=[]
 while todo:
  v=todo.pop();part.append(v)
  for edge in v.link_edges:
   other=edge.other_vert(v)
   if other in remaining:remaining.remove(other);todo.append(other)
 if len(part)>1000 and len(part)<4000:cloth.extend(part)
# Gentle tangential relaxation at the palm/thenar web removes the sharp source
# ridges without pulling the seated cuff or changing finger contact endpoints.
selected=[]
for v in cloth:
 side='Left' if v.co.x>0 else 'Right';w,axis,n,lat,length=frames[side];t=(v.co-w).dot(axis)/length
 if .15<t<.85:selected.append(v)
for _ in range(4):bmesh.ops.smooth_vert(bm,verts=selected,factor=.25,use_axis_x=True,use_axis_y=True,use_axis_z=True)
bm.to_mesh(o.data);bm.free();o.data.update()
assert len(bpy.context.scene.objects)==count
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'scripts/vector_fighter/f13-hand-anatomy.blend'),compress=True)
spec=importlib.util.spec_from_file_location('vector_build',ROOT/'scripts/vector_fighter/build.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g);g.rig=rig
meshes=[m for m in bpy.context.scene.objects if m.type=='MESH' and m.name!='weapon:joined'];arm_parts=[m for m in meshes if ('LowerArm' in m.name or 'gloves' in m.name or ('UpperArm' in m.name and 'fabric' in m.name))];body_parts=[m for m in meshes if m not in arm_parts]
def join(items,name):
 bpy.ops.object.select_all(action='DESELECT')
 for item in items:item.select_set(True)
 bpy.context.view_layer.objects.active=items[0];bpy.ops.object.join();items[0].name=name;return items[0]
arms=join(arm_parts,'VECTOR world forearms');body=join(body_parts,'VECTOR body');equipment=[m for m in bpy.context.scene.objects if m.type!='MESH' or m.name=='weapon:joined']
g.export(OUT/'candidate-body.glb',equipment+[arms,body]);arms.name='vector-armored-hands';g.export(OUT/'candidate-arms.glb',equipment+[arms])
(OUT/'anatomy-report.json').write_text(json.dumps({'source':'f11-fps-forms.blend','changed_glove_vertices':changed,'palm_relaxed_vertices':len(selected),'objects':count,'bones_and_actions':'unchanged','status':'candidate, requires native contact review'},indent=2)+'\n')
