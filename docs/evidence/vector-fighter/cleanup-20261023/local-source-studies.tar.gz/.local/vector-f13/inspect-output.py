import bpy,collections
bpy.ops.wm.open_mainfile(filepath='scripts/vector_fighter/f13-hand-anatomy.blend')
o=bpy.data.objects['VECTOR articulated gloves'];counts=collections.Counter();bad=0
for p in o.data.polygons:counts[o.data.materials[p.material_index].name]+=1
for v in o.data.vertices:
 if abs(sum(g.weight for g in v.groups)-1)>.01:bad+=1
print('VERTS',len(o.data.vertices),'FACES',counts,'BAD_WEIGHTS',bad,'MODIFIERS',[(m.name,m.type) for m in o.modifiers])
for mat in ['material.001','vector-glove.001','vector-ceramic.001']:
 ids={i for p in o.data.polygons if o.data.materials[p.material_index].name==mat for i in p.vertices};c=collections.Counter();wrong=[]
 for i in ids:
  v=o.data.vertices[i]
  g=max(v.groups,key=lambda g:g.weight);name=o.vertex_groups[g.group].name;c[name]+=1
  if (v.co.x>0 and name.startswith('Right')) or (v.co.x<0 and name.startswith('Left')):wrong.append(i)
 print(mat,len(ids),c,'wrong',len(wrong));print('RANGE',[(min(o.data.vertices[i].co[k] for i in ids),max(o.data.vertices[i].co[k] for i in ids)) for k in range(3)])
