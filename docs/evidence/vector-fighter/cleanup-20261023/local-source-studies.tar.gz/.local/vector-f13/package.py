from pathlib import Path
import shutil,json,gzip,hashlib,xml.etree.ElementTree as ET
out=Path('docs/evidence/vector-fighter/f13-result');(out/'frames').mkdir(parents=True,exist_ok=True);(out/'qa').mkdir(exist_ok=True)
for pattern in ['*.png','*.csv']:
 for p in Path('.local/vector-f13/final-native').glob(pattern):shutil.copyfile(p,out/'frames'/p.name)
checks={}
for phase in ['study-1','study-2','study-3','study-4','study-5','study-6','study','final-before-material-fix','final-native','history']:
 root=Path('.local/vector-f13')/phase
 for name in ['results.xml','editor.log','runner.log']:
  p=root/name
  if p.exists():
   if p.suffix=='.log':
    with gzip.open(out/'qa'/(phase+'-'+name+'.gz'),'wb') as f:f.write(p.read_bytes())
   else:
    shutil.copyfile(p,out/'qa'/(phase+'-'+name));xml=ET.parse(p).getroot();checks[phase]={k:xml.get(k) for k in ['result','total','passed','failed','skipped','duration']};checks[phase]['cases']=[{'name':c.get('name'),'result':c.get('result')} for c in xml.iter('test-case')]
for name in ['qa-scope.md','final-check.sh','import-final.sh','compare_glb.py','glb-verification.json','anatomy-report.json','montage.py','rest-preview.png']:
 shutil.copyfile(Path('.local/vector-f13')/name,out/'qa'/name)
for name in ['export-final-materials.log','import.log','import-runner.log']:
 with gzip.open(out/'qa'/(name+'.gz'),'wb') as f:f.write((Path('.local/vector-f13')/name).read_bytes())
source_paths=['scripts/vector_fighter/refine_hand_anatomy.py','scripts/vector_fighter/f13-hand-anatomy.blend','unity/Assets/StarTournament/Runtime/Core/TrooperProfile.cs','unity/Assets/StarTournament/Runtime/Core/DesignLabHistory.cs','unity/Assets/StarTournament/Tests/PlayMode/TrooperPresentationTests.cs','unity/Assets/StarTournament/Tests/EditMode/DesignLabHistoryTests.cs']
meta={'baseline':'b55259a5a01b709b3a6260a9d54d163cbe149937','branch':'codex/vector-fighter','checks':checks,'source_hashes':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in source_paths},'visual_iterations':{'study-1':'Rejected: inherited thumb-web tears','study-2':'Rejected: volume loss from open source surfaces','study-3':'Rejected: source skin folds','study-4':'Rejected: remaining surface artifacts','study-5':'Rejected: inadequate inherited cloth; approach replaced','study-6':'Closed authored volume; finger-length/skin-region correction still needed','study':'Refined anatomical volume before final thenar/plate seating adjustment'},'material_regression':'First final run: 5/6 PASS; identity test failed because neutral material regions collapsed to2. Restored cuff/palm/flush stitch/chassis regions without weakening the >=4 contract. Re-ran identity plus FPS capture:2/2 PASS; unchanged placement/pose checks retain their original passes.', 'unchanged':['rig hierarchy','all seven sampled animation arrays','upper/lower arm and wrist transforms','left support contacts','camera/FOV','weapon transforms','gameplay'],'not_run':['full suite','Player build','physical devices','performance','human acceptance','merge','release','deploy']}
(out/'verification.json').write_text(json.dumps(meta,indent=2)+'\n')
# Exact arm positions in actual captures, independent of the test that compares profiles.
names=['LeftUpperArm','LeftLowerArm','LeftHand','LeftMiddleProximal','RightUpperArm','RightLowerArm','RightHand']
def read(p):
 r={}
 for l in p.read_text().splitlines():
  a=l.split(',')
  if a[0] in names:r[a[0]]=list(map(float,a[1:]))
 return r
report={}
for w in ['Rifle','Shotgun','RocketLauncher','Cutter']:
 old=read(Path('docs/evidence/vector-fighter/f12-result/frames')/(w+'-grip.csv'));new=read(out/'frames'/(w+'-grip.csv'))
 report[w]={n:sum((a-b)**2 for a,b in zip(old[n],new[n]))**.5 for n in names}
assert max(x for r in report.values() for x in r.values())<.0001
(out/'arm-placement.json').write_text(json.dumps(report,indent=2)+'\n')
