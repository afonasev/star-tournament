import bpy,json
from mathutils import Vector
from pathlib import Path
bpy.ops.wm.open_mainfile(filepath='scripts/vector_fighter/f11-fps-forms.blend')
r=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');o=bpy.data.objects['VECTOR articulated gloves']
print('MATRIX',list(o.matrix_world),list(r.matrix_world))
for side in ['Left','Right']:
 for d in ['LowerArm','Hand','ThumbProximal','ThumbIntermediate','ThumbDistal','IndexProximal','MiddleProximal','RingProximal','LittleProximal']:
  b=r.data.bones[side+d];print(side+d,tuple(b.head_local),tuple(b.tail_local))
