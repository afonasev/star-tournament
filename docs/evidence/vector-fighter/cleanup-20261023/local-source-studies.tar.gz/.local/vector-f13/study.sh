#!/bin/sh
set -eu
python3 - <<'PY'
from pathlib import Path
import shutil,json,hashlib
art=Path('unity/Assets/StarTournament/Art')
for kind in ['body','arms']:shutil.copyfile(Path('.local/vector-f13')/f'candidate-{kind}.glb',art/f'trooper-{kind}-animated.glb')
p=art/'asset-manifest.json';d=json.loads(p.read_text())
for e in d['entries']:
 if e.get('key') in ['player-body','player-hands']:e['sha256']=hashlib.sha256((Path('unity')/e['path']).read_bytes()).hexdigest()
p.write_text(json.dumps(d,indent=2)+'\n')
PY
UNITY_RUN_MODE=shared unity/tools.sh editor -batchmode -noaudio -muted -quit -executeMethod StarTournament.ProvingGround.Editor.TrooperPreparation.RefreshExistingScene -logFile "$PWD/.local/vector-f13/import.log" > .local/vector-f13/import-runner.log 2>&1
mkdir -p .local/vector-f13/study
STAR_TOURNAMENT_GRIP_FACTORY=1 STAR_TOURNAMENT_GRIP_MESH=1 STAR_TOURNAMENT_GRIP_OVERRIDES="$PWD/.local/vector-f13/grip-study.txt" STAR_TOURNAMENT_WALK_EVIDENCE="$PWD/.local/vector-f13/study" STAR_TOURNAMENT_QA_LAB_HISTORY="$PWD/.local/vector-f13/study/history.json" UNITY_RUN_MODE=shared unity/tools.sh editor -batchmode -noaudio -muted -runTests -testPlatform PlayMode -testFilter FirstPersonStepsStaySmoothAndIndependentInTheRenderedScene -testResults "$PWD/.local/vector-f13/study/results.xml" -logFile "$PWD/.local/vector-f13/study/editor.log" > .local/vector-f13/study/runner.log 2>&1
