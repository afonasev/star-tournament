from pathlib import Path
p=Path('unity/Assets/StarTournament/Runtime/Core/TrooperProfile.cs');s=p.read_text();marker='        // Exact @17 factory poses remain available to saved Lab snapshots.'
s=s.replace(marker,'''        // Preserve exact @18 digit poses for existing Lab histories.
        internal ProvingProfile BeforeRefinedHandAnatomy()
        {
            if(id!="unity-trooper-presentation-v1"||version<19)return this;
            var p=DetachedCopy();p.version=18;
            var weapons=new[]{WeaponId.Rifle,WeaponId.Shotgun,WeaponId.RocketLauncher,WeaponId.Cutter};
            var old=new float[,]{{-2,4,2,0},{0,6,3,0},{3,8,4,0},{2,7,5,0}};
            var joints=new[]{"Proximal","Intermediate","Distal","Spread"};
            for(int w=0;w<weapons.Length;w++)for(int j=0;j<joints.Length;j++)
            {
                var path="grip."+weapons[w]+".right.Thumb."+joints[j];
                p.FindDescriptor(path).DefaultValue=old[w,j];p.Set(path,old[w,j]);
            }
            return p;
        }
'''+marker).replace('var p=DetachedCopy();p.version=17;','var p=BeforeRefinedHandAnatomy().DetachedCopy();p.version=17;').replace('version=18};','version=19};')
idx=s.rindex('            return p;');fits='            // Thumb opposition closes the grip without moving the wrist or arm.\n'
for line in Path('.local/vector-f13/grip-study.txt').read_text().splitlines():
 path,value=line.split('=');fits+='            Fit("'+path+'",'+value+');\n'
s=s[:idx]+fits+s[idx:];p.write_text(s)
p=Path('unity/Assets/StarTournament/Runtime/Core/DesignLabHistory.cs');s=p.read_text();marker='            if((sought.Profiles.FirstOrDefault(p=>p.Id=="unity-trooper-presentation-v1")?.Version??18)<18)';s=s.replace(marker,'''            if((sought.Profiles.FirstOrDefault(p=>p.Id=="unity-trooper-presentation-v1")?.Version??19)<19)
                shipped=new LabBundle{Profiles=shipped.Profiles.Select(p=>p.BeforeRefinedHandAnatomy()).ToList()};
'''+marker);p.write_text(s)
p=Path('unity/Assets/StarTournament/Tests/EditMode/DesignLabHistoryTests.cs');s=p.read_text().replace('[TestCase("BeforeStableSupportGrip")]','[TestCase("BeforeRefinedHandAnatomy")]\n        [TestCase("BeforeStableSupportGrip")]');p.write_text(s)
p=Path('unity/Assets/StarTournament/Tests/PlayMode/TrooperPresentationTests.cs');s=p.read_text();a=s.index('        [UnityTest] public IEnumerator FactorySupportGripsKeepForearmDirectionAndNaturalWrist()');b=s.index('        [UnityTest]',a+20);part=s[a:b].replace('var current=ProvingProfile.CreateTrooperDefault();','var current=BeforeRefinedHandAnatomy(ProvingProfile.CreateTrooperDefault());');s=s[:a]+part+s[b:]
marker='        static ProvingProfile BeforeStableSupportGrip(ProvingProfile profile)';test='''        static ProvingProfile BeforeRefinedHandAnatomy(ProvingProfile profile)
        {
            return (ProvingProfile)typeof(ProvingProfile).GetMethod("BeforeRefinedHandAnatomy",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).Invoke(profile,null);
        }
        [UnityTest] public IEnumerator RefinedHandGripPreservesArmAndWeaponPlacement()
        {
            yield return Load(2);
            var visual=ground.transform.Find("seat-camera-1/trooper-view").GetComponent<TrooperVisual>();
            var current=ProvingProfile.CreateTrooperDefault();var previous=BeforeRefinedHandAnatomy(current);
            var fixedBones=visual.GetComponentsInChildren<Transform>().Where(t=>
                t.name=="trooper:rig:weapon-mount"||((t.name.StartsWith("Left")||t.name.StartsWith("Right"))&&!t.name.StartsWith("RightThumb"))).ToArray();
            foreach(WeaponId weapon in System.Enum.GetValues(typeof(WeaponId)))
            {
                visual.EquippedWeapon=weapon;
                foreach(var d in previous.Descriptors)visual.Tuning.Set(d.Path,d.DefaultValue);
                visual.ResetPose(0);visual.Render(.25,Vector3.zero,100,1);
                var positions=fixedBones.Select(t=>t.position).ToArray();var rotations=fixedBones.Select(t=>t.rotation).ToArray();
                foreach(var d in current.Descriptors)visual.Tuning.Set(d.Path,d.DefaultValue);
                visual.ResetPose(0);visual.Render(.25,Vector3.zero,100,1);
                for(int i=0;i<fixedBones.Length;i++)
                {
                    Assert.That(Vector3.Distance(positions[i],fixedBones[i].position),Is.LessThan(.0001f),weapon+" "+fixedBones[i].name);
                    Assert.That(Quaternion.Angle(rotations[i],fixedBones[i].rotation),Is.LessThan(.05f),weapon+" "+fixedBones[i].name);
                }
            }
        }
''';assert marker in s;s=s.replace(marker,test+marker);p.write_text(s)
