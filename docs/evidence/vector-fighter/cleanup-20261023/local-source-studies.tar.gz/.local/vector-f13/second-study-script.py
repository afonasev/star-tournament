"""F13: reshape existing gloves around the unchanged F12 hand skeleton.
Palm thickness, thumb web and finger pads are edited in the bind surface;
existing material layers follow the same continuous deformation. No arm edits.
"""
import bpy,bmesh,math,json,importlib.util
from pathlib import Path
from mathutils import Vector
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'.local/vector-f13';OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'scripts/vector_fighter/f11-fps-forms.blend'))
rig=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');o=bpy.data.objects['VECTOR articulated gloves'];count=len(bpy.context.scene.objects)
frames={}
for side,sign in [('Left',1),('Right',-1)]:
 wrist=rig.data.bones[side+'Hand'].head_local.copy();end=sum((rig.data.bones[side+d+'Proximal'].head_local for d in ['Index','Middle','Ring','Little']),Vector())/4
 axis=(end-wrist).normalized();normal=Vector((sign,0,1)).normalized();normal=(normal-axis*normal.dot(axis)).normalized();lateral=normal.cross(axis).normalized()
 frames[side]=(wrist,axis,normal,lateral,(end-wrist).length)
def smooth(a,b,x):
 t=max(0,min(1,(x-a)/(b-a)));return t*t*(3-2*t)
changed=0
for v in o.data.vertices:
 p=v.co.copy();side='Left' if p.x>0 else 'Right';w,axis,n,lat,length=frames[side];rel=p-w;t=rel.dot(axis)/length;depth=rel.dot(n)
 # Preserve the seated cuff and knuckle line; reduce the padded spherical palm
 # to a flatter metacarpal volume with a gradual thenar/hypothenar transition.
 palm=smooth(.02,.22,t)*(1-smooth(.72,1.04,t))
 p-=n*depth*.36*palm
 # Taper the palm heel into the unchanged cuff instead of an abrupt bulge.
 heel=smooth(.02,.20,t)*(1-smooth(.32,.72,t))
 p-=lat*rel.dot(lat)*.14*heel
 # Follow the nearest finger chain only after its root web. The palmar contact
 # half stays in place; flatten the dorsal padding, preserving gripping pads.
 chains=[]
 for digit in ['Thumb','Index','Middle','Ring','Little']:
  chain=[rig.data.bones[side+digit+s] for s in ['Proximal','Intermediate','Distal']]
  for b in chain:
   d=b.tail_local-b.head_local;u=max(0,min(1,(v.co-b.head_local).dot(d)/d.length_squared));q=b.head_local+d*u
   chains.append(((v.co-q).length,digit,b,q,d.normalized()))
 _,digit,b,q,d=min(chains,key=lambda item:item[0]);root=rig.data.bones[side+digit+'Proximal'];advance=(v.co-root.head_local).dot((root.tail_local-root.head_local).normalized())
 if advance>0:
  fade=smooth(0,.018,advance);radial=v.co-q;dn=n-d*n.dot(d);dn.normalize();dorsal=radial.dot(dn)
  if dorsal>0:p-=dn*dorsal*.20*fade
  # A less swollen thumb shaft, while retaining its pad and bone positions.
  if digit=='Thumb':p-=(radial-dn*dorsal)*.10*fade
 if (p-v.co).length>1e-7:changed+=1
 v.co=p
o.data.update()
# Rebuild the two continuous textile shells to remove the inherited folded
# thumb web. Keep original UV/color roles and transfer skin to the new surface.
from mathutils.bvhtree import BVHTree
bm=bmesh.new();bm.from_mesh(o.data);bm.verts.ensure_lookup_table();bm.verts.index_update();remaining=set(bm.verts);cloth=[]
while remaining:
 todo=[remaining.pop()];part=[]
 while todo:
  v=todo.pop();part.append(v)
  for edge in v.link_edges:
   other=edge.other_vert(v)
   if other in remaining:remaining.remove(other);todo.append(other)
 if len(part)>1000 and len(part)<4000:cloth.extend(v.index for v in part)
bm.free();cloth=set(cloth)
o.data.calc_loop_triangles();tris=[tuple(t.vertices) for t in o.data.loop_triangles if all(i in cloth for i in t.vertices)]
source=[v.co.copy() for v in o.data.vertices];oldweights=[{o.vertex_groups[g.group].name:g.weight for g in v.groups} for v in o.data.vertices]
tree=BVHTree.FromPolygons(source,tris,all_triangles=True)
shell=o.copy();shell.data=o.data.copy();bpy.context.collection.objects.link(shell)
bm=bmesh.new();bm.from_mesh(shell.data);bm.verts.ensure_lookup_table();bmesh.ops.delete(bm,geom=[v for v in bm.verts if v.index not in cloth],context='VERTS');bm.to_mesh(shell.data);bm.free()
bpy.context.view_layer.objects.active=shell
for mod in list(shell.modifiers):shell.modifiers.remove(mod)
mod=shell.modifiers.new('Continuous anatomical glove surface','REMESH');mod.mode='VOXEL';mod.voxel_size=.0015;mod.use_smooth_shade=True;bpy.ops.object.modifier_apply(modifier=mod.name)
mod=shell.modifiers.new('Relax thumb web','SMOOTH');mod.factor=.6;mod.iterations=4;bpy.ops.object.modifier_apply(modifier=mod.name)
def assign(obj,index,weights):
 for group in obj.vertex_groups:group.remove([index])
 weights=dict(sorted(weights.items(),key=lambda x:-x[1])[:4]);total=sum(weights.values())
 for name,value in weights.items():
  if value>0:(obj.vertex_groups.get(name) or obj.vertex_groups.new(name=name)).add([index],value/total,'REPLACE')
for v in shell.data.vertices:
 hit,normal,idx,dist=tree.find_nearest(v.co);aa,bb,cc=tris[idx];x=source[bb]-source[aa];y=source[cc]-source[aa];z=hit-source[aa];den=x.dot(x)*y.dot(y)-x.dot(y)**2
 u=(y.dot(y)*z.dot(x)-x.dot(y)*z.dot(y))/den if abs(den)>1e-15 else 0;vv=(x.dot(x)*z.dot(y)-x.dot(y)*z.dot(x))/den if abs(den)>1e-15 else 0
 weights={}
 for ii,factor in [(aa,1-u-vv),(bb,u),(cc,vv)]:
  for name,value in oldweights[ii].items():weights[name]=weights.get(name,0)+max(0,factor)*value
 # A continuous thenar transition, not a rigid thumb plug in the palm.
 side='Left' if v.co.x>0 else 'Right';thumb=rig.data.bones[side+'ThumbProximal'];axis=(thumb.tail_local-thumb.head_local).normalized();advance=(v.co-thumb.head_local).dot(axis)
 thumb_total=sum(value for name,value in weights.items() if name.startswith(side+'Thumb'))
 if thumb_total>.05 and advance<.025:
  f=smooth(-.025,.035,advance);weights={side+'Hand':1-f,side+'ThumbProximal':f}
 assign(shell,v.index,weights)
# Continuous UVs in the hand frame, avoiding inherited stretched web triangles.
uv=shell.data.uv_layers.new(name='UVMap')
for loop in shell.data.loops:
 v=shell.data.vertices[loop.vertex_index];side='Left' if v.co.x>0 else 'Right';w,axis,n,lat,length=frames[side];r=v.co-w
 uv.data[loop.index].uv=(r.dot(lat)*3,r.dot(axis)*3)
for face in shell.data.polygons:face.use_smooth=True;face.material_index=0
bm=bmesh.new();bm.from_mesh(o.data);bm.verts.ensure_lookup_table();bmesh.ops.delete(bm,geom=[v for v in bm.verts if v.index in cloth],context='VERTS');bm.to_mesh(o.data);bm.free()
# Re-seat all existing seam islands on the clean textile and give them its
# deformation. The ceramic assemblies retain their authored material roles.
shell.data.calc_loop_triangles();surface=[v.co.copy() for v in shell.data.vertices];triangles=[tuple(t.vertices) for t in shell.data.loop_triangles];surf=BVHTree.FromPolygons(surface,triangles,all_triangles=True)
seam_ids={i for face in o.data.polygons if "seam" in o.data.materials[face.material_index].name for i in face.vertices}
for v in o.data.vertices:
 hit,normal,idx,dist=surf.find_nearest(v.co)
 # Keep the existing layer's signed relief while removing submerged vertices.
 if v.index in seam_ids and dist<.015:v.co=hit+normal*.0003
 # Match deformation on the cloth web; use the nearest triangle's blended skin.
 a,b,c=triangles[idx];x=surface[b]-surface[a];y=surface[c]-surface[a];z=hit-surface[a];den=x.dot(x)*y.dot(y)-x.dot(y)**2
 u=(y.dot(y)*z.dot(x)-x.dot(y)*z.dot(y))/den if abs(den)>1e-15 else 0;vv=(x.dot(x)*z.dot(y)-x.dot(y)*z.dot(x))/den if abs(den)>1e-15 else 0
 weights={}
 for ii,factor in [(a,1-u-vv),(b,u),(c,vv)]:
  for group in shell.data.vertices[ii].groups:
   name=shell.vertex_groups[group.group].name;weights[name]=weights.get(name,0)+max(0,factor)*group.weight
 assign(o,v.index,weights)
bpy.ops.object.select_all(action='DESELECT');o.select_set(True);shell.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.join()
selected=cloth
assert len(bpy.context.scene.objects)==count
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'scripts/vector_fighter/f13-hand-anatomy.blend'),compress=True)
spec=importlib.util.spec_from_file_location('vector_build',ROOT/'scripts/vector_fighter/build.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g);g.rig=rig
meshes=[m for m in bpy.context.scene.objects if m.type=='MESH' and m.name!='weapon:joined'];arm_parts=[m for m in meshes if ('LowerArm' in m.name or 'gloves' in m.name or ('UpperArm' in m.name and 'fabric' in m.name))];body_parts=[m for m in meshes if m not in arm_parts]
def join(items,name):
 bpy.ops.object.select_all(action='DESELECT')
 for item in items:item.select_set(True)
 bpy.context.view_layer.objects.active=items[0];bpy.ops.object.join();items[0].name=name;return items[0]
arms=join(arm_parts,'VECTOR world forearms');body=join(body_parts,'VECTOR body');equipment=[m for m in bpy.context.scene.objects if m.type!='MESH' or m.name=='weapon:joined']
g.export(OUT/'candidate-body.glb',equipment+[arms,body]);arms.name='vector-armored-hands';g.export(OUT/'candidate-arms.glb',equipment+[arms])
(OUT/'anatomy-report.json').write_text(json.dumps({'source':'f11-fps-forms.blend','changed_glove_vertices':changed,'palm_relaxed_vertices':len(selected),'objects':count,'bones_and_actions':'unchanged','status':'candidate, requires native contact review'},indent=2)+'\n')
