from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
root=Path('docs/evidence/vector-fighter/f13-result');frames=root/'frames';font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',24)
im=Image.new('RGB',(1600,920),'#181d24');draw=ImageDraw.Draw(im)
for i,w in enumerate(['Rifle','Shotgun','RocketLauncher','Cutter']):
 src=Image.open(frames/(w+'-fps.png')).crop((260,850,1200,1350)).resize((800,426));x=i%2*800;y=i//2*460;im.paste(src,(x,y+34));draw.text((x+12,y+3),w+' | F13 actual FPS',font=font,fill='white')
im.save(root/'fps-four-weapons.png')
im=Image.new('RGB',(1600,1736),'#181d24');draw=ImageDraw.Draw(im)
for row,w in enumerate(['Rifle','Shotgun','RocketLauncher','Cutter']):
 for col,(side,sign) in enumerate([('Left',-1),('Left',1),('Right',-1),('Right',1)]):
  x=col*400;y=row*434;im.paste(Image.open(frames/(w+'-'+side+'-grip-'+str(sign)+'.png')).resize((400,400)),(x,y+34));draw.text((x+7,y+3),w+' '+side+' '+str(sign),font=font,fill='white')
im.save(root/'hand-closeups.png')
im=Image.new('RGB',(1600,534),'#181d24');draw=ImageDraw.Draw(im)
for i,(folder,label) in enumerate([(Path('docs/evidence/vector-fighter/f12-result/frames'),'F12 before'),(frames,'F13 after')]):
 src=Image.open(folder/'Rifle-fps.png').crop((400,850,1200,1350));im.paste(src,(i*800,34));draw.text((i*800+12,3),label,font=font,fill='white')
im.save(root/'rifle-before-after.png')
