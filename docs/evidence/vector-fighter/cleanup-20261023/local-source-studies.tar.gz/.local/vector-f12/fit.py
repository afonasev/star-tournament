import numpy as np,csv
from pathlib import Path
def rot(axis,deg):
 a=np.deg2rad(deg);c=np.cos(a);s=np.sin(a)
 return np.array([[1,0,0],[0,c,-s],[0,s,c]]) if axis=='x' else np.array([[c,0,s],[0,1,0],[-s,0,c]])
base=Path('.local/vector-f9/native')
def bones(w):
 out={}
 for l in (base/(w+'-grip.csv')).read_text().splitlines()[1:]:
  a=l.split(',')
  if len(a)==4:
   try:out[a[0]]=np.array(list(map(float,a[1:])))
   except:pass
 return out
def unit(v):return v/np.linalg.norm(v)
for w,z in [('RocketLauncher',.49),('Cutter',.406)]:
 b=bones(w);a,e,c,p=[b[x] for x in ['LeftUpperArm','LeftLowerArm','LeftHand','LeftMiddleProximal']];L1=np.linalg.norm(e-a);L2=np.linalg.norm(c-e)
 for yaw in [15,25,35,45]:
  # original turn Rx(8)Ry(1); new Rx(8)Ry(yaw)
  turn=rot('x',8)@rot('y',yaw-1)@rot('x',-8)
  center=np.array([0,-.11,z]);pp=center+turn@(p-center);cc=center+turn@(c-center)
  d=unit(cc-a);bend=unit(e-a-d*np.dot(e-a,d));dist=np.linalg.norm(cc-a);along=(L1*L1+dist*dist-L2*L2)/(2*dist);ee=a+d*along+bend*np.sqrt(L1*L1-along*along)
  angle=np.degrees(np.arccos(np.clip(np.dot(unit(cc-ee),unit(pp-cc)),-1,1)))
  print(w,yaw,'angle',round(angle,2),'p',pp.round(4),'c',cc.round(4),'e',ee.round(4))
# Recover sampled upper-arm direction from two known solved elbows (same clip).
base=Path('.local/vector-f9/native');ref=bones('Rifle');a=ref['LeftUpperArm'];L1=np.linalg.norm(ref['LeftLowerArm']-a);L2=np.linalg.norm(ref['LeftHand']-ref['LeftLowerArm']);normals=[]
for w in ['Rifle','Shotgun','RocketLauncher','Cutter']:
 b=bones(w);normals.append(unit(np.cross(b['LeftHand']-a,b['LeftLowerArm']-a)))
_,_,vh=np.linalg.svd(normals);orig=vh[-1];orig*=np.sign(np.dot(orig,ref['LeftLowerArm']-a));print('ORIG',orig,'normals',np.array(normals)@orig)
for w,z in [('RocketLauncher',.49),('Cutter',.406)]:
 b=bones(w);c=b['LeftHand'];p=b['LeftMiddleProximal']
 for yaw in [10,15,20,25,30,35]:
  turn=rot('x',8)@rot('y',yaw-1)@rot('x',-8);center=np.array([0,-.11,z]);pp=center+turn@(p-center);cc=center+turn@(c-center)
  d=unit(cc-a);bend=unit(orig-d*np.dot(orig,d));dist=np.linalg.norm(cc-a);along=(L1*L1+dist*dist-L2*L2)/(2*dist);ee=a+d*along+bend*np.sqrt(L1*L1-along*along)
  angle=np.degrees(np.arccos(np.clip(np.dot(unit(cc-ee),unit(pp-cc)),-1,1)))
  print('true',w,yaw,round(angle,1),ee.round(3))
for w,z in [('RocketLauncher',.49),('Cutter',.406)]:
 b=bones(w);c=b['LeftHand'];p=b['LeftMiddleProximal'];best=[]
 for pitch in range(-20,21,2):
  for yaw in range(0,31,2):
   for sy in [-.15,-.13,-.11,-.09,-.07]:
    turn=rot('x',pitch)@rot('y',yaw-1)@rot('x',-8);center=np.array([0,-.11,z]);pp=center+turn@(p-center)+np.array([0,sy+.11,0]);cc=pp+turn@(c-p)
    d=unit(cc-a);bend=unit(orig-d*np.dot(orig,d));dist=np.linalg.norm(cc-a);along=(L1*L1+dist*dist-L2*L2)/(2*dist);ee=a+d*along+bend*np.sqrt(max(0,L1*L1-along*along))
    angle=np.degrees(np.arccos(np.clip(np.dot(unit(cc-ee),unit(pp-cc)),-1,1)));arm=np.degrees(np.arccos(np.clip(np.dot(unit(cc-ee),unit(ref['LeftHand']-ref['LeftLowerArm'])),-1,1)))
    score=angle**2+arm**2+np.linalg.norm(ee-ref['LeftLowerArm'])**2*1000
    best.append((score,pitch,yaw,sy,angle,arm,pp,ee))
 for v in sorted(best,key=lambda x:x[0])[:3]:print('best',w,v[:6],v[6].round(5),v[7].round(4))
