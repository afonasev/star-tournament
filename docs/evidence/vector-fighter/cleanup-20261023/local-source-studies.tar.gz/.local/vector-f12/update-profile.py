from pathlib import Path
p=Path('unity/Assets/StarTournament/Runtime/Core/TrooperProfile.cs');s=p.read_text();s=s.replace('version=17};','version=18};')
marker='        // Exact @16 schema/defaults remain available to saved Lab snapshots.'
s=s.replace(marker,'''        // Exact @17 factory poses remain available to saved Lab snapshots.
        internal ProvingProfile BeforeStableSupportGrip()
        {
            if(id!="unity-trooper-presentation-v1"||version<18)return this;
            var p=DetachedCopy();p.version=17;
            foreach(var weapon in new[]{WeaponId.RocketLauncher,WeaponId.Cutter})
            {
                var prefix="grip."+weapon+".";
                void Restore(string name,float value){var d=p.FindDescriptor(prefix+name);d.DefaultValue=value;p.Set(d.Path,value);}
                Restore("wristAlignment",1);Restore("supportPitch",8);Restore("supportYaw",1);
                Restore("supportX",-.105f);Restore("supportY",-.11f);Restore("supportZ",weapon==WeaponId.RocketLauncher?.46f:.375f);
            }
            return p;
        }
'''+marker).replace('var p=DetachedCopy();p.version=16;','var p=BeforeStableSupportGrip().DetachedCopy();p.version=16;')
s=s.replace('weapon==WeaponId.RocketLauncher||weapon==WeaponId.Cutter?1:0);','0);')
for w,pitch,yaw,x,y,z in [('RocketLauncher','0','18','-0.1091','-0.15418','0.49229'),('Cutter','-2','22','-0.10903','-0.154','0.41512')]:
 import re
 for key,v in [('supportPitch',pitch),('supportYaw',yaw),('supportX',x),('supportY',y),('supportZ',z)]:
  s=re.sub(r'Fit\("grip\.'+w+r'\.'+key+r'",[^)]+\);','Fit("grip.'+w+'.'+key+'",'+v+'f);',s)
p.write_text(s)
p=Path('unity/Assets/StarTournament/Runtime/Core/DesignLabHistory.cs');s=p.read_text();marker='            if((sought.Profiles.FirstOrDefault(p=>p.Id=="unity-trooper-presentation-v1")?.Version??17)<17)';s=s.replace(marker,'''            if((sought.Profiles.FirstOrDefault(p=>p.Id=="unity-trooper-presentation-v1")?.Version??18)<18)
                shipped=new LabBundle{Profiles=shipped.Profiles.Select(p=>p.BeforeStableSupportGrip()).ToList()};
'''+marker);p.write_text(s)
p=Path('unity/Assets/StarTournament/Tests/EditMode/DesignLabHistoryTests.cs');s=p.read_text().replace('[TestCase("BeforeAlignedSupportWrist")]','[TestCase("BeforeStableSupportGrip")]\n        [TestCase("BeforeAlignedSupportWrist")]');p.write_text(s)
p=Path('unity/Assets/StarTournament/Tests/PlayMode/TrooperPresentationTests.cs');s=p.read_text();start=s.index('        [UnityTest] public IEnumerator SupportWristAlignmentPreservesPalmDigitsAndBoneLengths()');end=s.index('        [UnityTest]',start+20)
part=s[start:end].replace('ProvingProfile.CreateTrooperDefault().Descriptors','ProvingProfile.CreateTrooperDefault().BeforeStableSupportGrip().Descriptors');s=s[:start]+part+s[end:];p.write_text(s)
