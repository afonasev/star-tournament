from pathlib import Path
import shutil,json,gzip,hashlib,xml.etree.ElementTree as ET,subprocess
out=Path('docs/evidence/vector-fighter/f12-result');(out/'frames').mkdir(parents=True,exist_ok=True);(out/'qa').mkdir(exist_ok=True)
for pattern in ['*.png','*.csv']:
 for p in Path('.local/vector-f12/final-native').glob(pattern):shutil.copyfile(p,out/'frames'/p.name)
checks={}
for phase in ['candidate','candidate-2','history','final-native','final-compile-failure','final-profile-step-failure']:
 root=Path('.local/vector-f12')/phase
 for name in ['results.xml','editor.log','runner.log']:
  p=root/name
  if p.exists():
   if p.suffix=='.log':
    with gzip.open(out/'qa'/(phase+'-'+name+'.gz'),'wb') as f:f.write(p.read_bytes())
   else:
    shutil.copyfile(p,out/'qa'/(phase+'-'+name));xml=ET.parse(p).getroot();checks[phase]={k:xml.get(k) for k in ['result','total','passed','failed','skipped','duration']};checks[phase]['cases']=[{'name':c.get('name'),'result':c.get('result')} for c in xml.iter('test-case')]
for name in ['qa-scope.md','check-history.sh','final-check.sh','measure.py','montage.py']:shutil.copyfile(Path('.local/vector-f12')/name,out/'qa'/name)
source_paths=['unity/Assets/StarTournament/Runtime/Core/TrooperProfile.cs','unity/Assets/StarTournament/Runtime/Core/DesignLabHistory.cs','unity/Assets/StarTournament/Tests/PlayMode/TrooperPresentationTests.cs','unity/Assets/StarTournament/Tests/EditMode/DesignLabHistoryTests.cs']
meta={'baseline':'610fef5bada4c7afeb9724197a4212a4379b7922','branch':'codex/vector-fighter','checks':checks,'source_hashes':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in source_paths},'failures':['First final run: test compilation failed on internal historical profile access; fixed with existing reflection pattern.','Second final run: exact fitted contact values violated Lab 0.005 step; stopped owned Editor (exit143), no complete XML; corrected factory contacts to existing step grid.'],'unchanged':['GLBs','Blender source','prefabs','weapon transforms','camera/FOV','finger curls','gameplay'],'not_run':['full suite','Player build','physical devices','human acceptance','merge','release','deploy']}
(out/'verification.json').write_text(json.dumps(meta,indent=2)+'\n')
