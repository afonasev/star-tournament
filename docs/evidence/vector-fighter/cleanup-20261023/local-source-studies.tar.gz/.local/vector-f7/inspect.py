import bpy,bmesh,json
from collections import Counter
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath='scripts/vector_fighter/f6-remodel-study.blend')
rig=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE')
print('BONES',[(b.name,tuple(b.head_local),tuple(b.tail_local)) for b in rig.data.bones if b.name.startswith('Left') and any(n in b.name for n in ['Hand','Index','Middle','Little','Thumb'])])
for o in bpy.context.scene.objects:
 if o.type!='MESH':continue
 print('MESH',o.name,len(o.data.vertices),[(m.name if m else '-') for m in o.data.materials])
 if 'glove' not in o.name:continue
 bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.000001)
 remaining=set(bm.verts);infos=[];layer=bm.verts.layers.deform.active
 while remaining:
  todo=[remaining.pop()];component=[]
  while todo:
   v=todo.pop();component.append(v)
   for e in v.link_edges:
    other=e.other_vert(v)
    if other in remaining:remaining.remove(other);todo.append(other)
  groups=Counter();center=sum((v.co for v in component),Vector())/len(component)
  for v in component:
   for i,w in v[layer].items():groups[o.vertex_groups[i].name]+=w
  infos.append((len(component),tuple(center),groups.most_common(5)))
 print('GLOVE_COMPONENTS',sorted(infos,reverse=True))
 bm.free()
