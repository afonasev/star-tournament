import bpy,bmesh
from mathutils import Vector
r=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');o=next(o for o in bpy.context.scene.objects if 'gloves' in o.name);bm=bmesh.new();bm.from_mesh(o.data);bm.verts.ensure_lookup_table();bm.verts.index_update();left=set(bm.verts)
while left:
 todo=[left.pop()];p=[]
 while todo:
  v=todo.pop();p.append(v)
  for e in v.link_edges:
   n=e.other_vert(v)
   if n in left:left.remove(n);todo.append(n)
 if len(p) not in [140,384]:continue
 c=o.matrix_world@(sum((v.co for v in p),Vector())/len(p));ws={}
 for v in p:
  for g in o.data.vertices[v.index].groups:ws[o.vertex_groups[g.group].name]=ws.get(o.vertex_groups[g.group].name,0)+g.weight/len(p)
 if not max(ws,key=ws.get).startswith('Left'):continue
 mat={o.material_slots[f.material_index].name for v in p for f in v.link_faces}
 print(len(p),tuple(round(x,4) for x in c),mat,sorted(ws.items(),key=lambda p:-p[1])[:3])
