from pathlib import Path
import json,hashlib,shutil,gzip,xml.etree.ElementTree as E
out=Path('docs/evidence/vector-fighter/f8');local=Path('.local/vector-f8')
checks={}
def add(name,src,xml):
 target=out/'qa'/name;target.mkdir(parents=True,exist_ok=True)
 r=E.parse(src/xml).getroot();keys=['result','total','passed','failed','skipped','duration','start-time','end-time'];checks[name]={k:r.get(k) for k in keys}
 shutil.copyfile(src/xml,target/'results.xml')
 for log in src.glob('*.log'):
  with gzip.open(target/(log.name+'.gz'),'wb') as f:f.write(log.read_bytes())
 return checks[name]
add('history-import',Path('.local/unity-evidence/focused-editmode.nbewGR'),'editmode.xml')
for name in ['neutral-filter-notrun','neutral','candidate','repaired','final','final-palm','final-rigid','final-dorsal','final-assembly']:add(name,local/name,'results.xml')
runner=(local/'assembly-import-runner.log').read_text();path=runner.split('Evidence: ')[1].splitlines()[0];add('final-import',Path(path),'editmode.xml')
(out/'grips').mkdir(exist_ok=True)
for f in (local/'final-assembly').glob('*.png'):shutil.copyfile(f,out/'grips'/f.name)
for src in ['glove-report.json','planning-validation.log','glb-structure.txt']:
 shutil.copyfile(local/src,out/src)
shutil.copyfile(local/'scope.md',out/'scope-original.md')
files=['scripts/vector_fighter/refine_glove.py','scripts/vector_fighter/f8-glove-repair.blend','unity/Assets/StarTournament/Art/trooper-body-animated.glb','unity/Assets/StarTournament/Art/trooper-arms-animated.glb','unity/Assets/StarTournament/Art/asset-manifest.json','unity/Assets/StarTournament/Trooper/TrooperBody.prefab','unity/Assets/StarTournament/Trooper/TrooperArms.prefab','unity/Assets/StarTournament/Runtime/Core/TrooperProfile.cs','unity/Assets/StarTournament/Runtime/Core/DesignLabHistory.cs','unity/Assets/StarTournament/Tests/EditMode/DesignLabHistoryTests.cs']
(out/'source-hashes.json').write_text(json.dumps({p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files},indent=2)+'\n')
(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps(checks,indent=2))
