from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
src=Path('docs/evidence/vector-fighter/f8/grips');out=src.parent
try:font=ImageFont.truetype('/System/Library/Fonts/Helvetica.ttc',22)
except OSError:font=ImageFont.load_default()
def grid(name,items,columns,w,h):
 image=Image.new('RGB',(columns*w,((len(items)+columns-1)//columns)*(h+32)),(24,29,34));draw=ImageDraw.Draw(image)
 for i,(file,label) in enumerate(items):
  x=(i%columns)*w;y=(i//columns)*(h+32);draw.text((x+12,y+5),label,font=font,fill='white');frame=Image.open(src/file);frame.thumbnail((w,h),Image.Resampling.LANCZOS);image.paste(frame,(x+(w-frame.width)//2,y+32+(h-frame.height)//2))
 image.save(out/name)
weapons=['RocketLauncher','Cutter']
grid('grips-both-sides.png',[(f'{w}-Left-grip-{s}.png',f'{w} / side {s:+}') for s in [1,-1] for w in weapons],2,600,600)
grid('fps.png',[(f'{w}-fps.png',f'{w} / actual seat camera') for w in weapons],2,600,675)
weapons=['Rifle','Shotgun','RocketLauncher','Cutter']
grid('all-weapons.png',[(f'{w}-Left-grip-{s}.png',f'{w} / side {s:+}') for s in [1,-1] for w in weapons],4,500,500)
