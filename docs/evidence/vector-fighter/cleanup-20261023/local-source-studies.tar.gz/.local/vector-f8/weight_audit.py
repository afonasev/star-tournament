import bpy,bmesh
from mathutils import Vector
r=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');o=next(o for o in bpy.context.scene.objects if 'gloves' in o.name)
names={g.index:g.name for g in o.vertex_groups};hits=[];multi=0
for v in o.data.vertices:
 ws=[(names[g.group],g.weight) for g in v.groups if g.weight>.05];digits={n[4:].replace('Proximal','').replace('Intermediate','').replace('Distal','') for n,w in ws if n.startswith('Left') and 'Hand' not in n}
 if len(digits)>1:
  multi+=1
  if any('Distal' in n or 'Intermediate' in n for n,w in ws):hits.append((v.index,tuple(o.matrix_world@v.co),ws))
print('CROSS_DIGIT',multi,'intermediate/distal',len(hits));print(hits[:15])
