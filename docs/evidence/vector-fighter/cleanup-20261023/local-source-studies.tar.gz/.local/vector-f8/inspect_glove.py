import bpy,json,bmesh
r=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE')
for b in r.data.bones:
 if b.name.startswith('Left') and any(x in b.name for x in ['Hand','Little','Ring','Middle','Index','Thumb']):print('BONE',b.name,b.parent.name,list(b.head_local),list(b.tail_local))
for o in bpy.context.scene.objects:
 if 'gloves' not in o.name:continue
 bm=bmesh.new();bm.from_mesh(o.data);left=set(bm.verts);parts=[]
 while left:
  todo=[left.pop()];p=[]
  while todo:
   v=todo.pop();p.append(v)
   for e in v.link_edges:
    n=e.other_vert(v)
    if n in left:left.remove(n);todo.append(n)
  parts.append(p)
 print('OBJECT',o.name,len(o.data.vertices),len(parts),'parts',sorted([len(p) for p in parts],reverse=True)[:55])
 for p in sorted(parts,key=len,reverse=True)[:25]:
  ws={}
  for v in p:
   for g in o.data.vertices[v.index].groups:ws[o.vertex_groups[g.group].name]=ws.get(o.vertex_groups[g.group].name,0)+g.weight/len(p)
  print('PART',len(p),sorted(ws.items(),key=lambda p:-p[1])[:6])
