import json,struct
from pathlib import Path
for kind in ['body','arms']:
 reports=[]
 for stem in ['pre-f8','candidate']:
  p=Path('.local/vector-f8')/f'{stem}-{kind}.glb';b=p.read_bytes();n=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+n]);reports.append({'name':p.name,'meshes':len(d['meshes']),'nodes':len(d['nodes']),'joints':len(d['skins'][0]['joints']),'animations':len(d['animations']),'materials':len(d['materials']),'vertices':sum(d['accessors'][p['attributes']['POSITION']]['count'] for m in d['meshes'] for p in m['primitives'])})
 print(kind,json.dumps(reports))
