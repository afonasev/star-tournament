import json,struct,hashlib
from pathlib import Path
import numpy as np
DT={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'};N={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}
def read(p):
 b=p.read_bytes();size=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+size]);binary=b[28+size:]
 def array(i):
  a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];dtype=np.dtype(DT[a['componentType']]);shape=(a['count'],N[a['type']]);offset=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',dtype.itemsize*shape[1]);return np.ndarray(shape,dtype,buffer=binary,offset=offset,strides=(stride,dtype.itemsize)).copy()
 return d,array
out={}
for kind in ['body','arms']:
 a,aa=read(Path('.local/vector-f8')/f'pre-f8-{kind}.glb');b,bb=read(Path('.local/vector-f8')/f'candidate-{kind}.glb');meshes=[]
 for m,n in zip(a['meshes'],b['meshes']):
  changed=0;total=0
  for p,q in zip(m['primitives'],n['primitives']):
   x,y=aa(p['attributes']['POSITION']),bb(q['attributes']['POSITION']);changed+=int(np.count_nonzero(np.any(np.abs(x-y)>1e-7,axis=1)));total+=len(x)
  meshes.append({'name':m['name'],'changed_position_vertices':changed,'total':total})
 anim_equal=all(np.array_equal(aa(x[k]),bb(y[k])) for m,n in zip(a['animations'],b['animations']) for x,y in zip(m['samplers'],n['samplers']) for k in ['input','output'])
 out[kind]={'meshes':meshes,'animation_samples_exactly_equal':anim_equal,'nodes_equal':a['nodes']==b['nodes']}
print(json.dumps(out,indent=2))
