#!/bin/sh
set -eu
root=$(pwd)
python3 - <<'PY'
from pathlib import Path
import shutil,json,hashlib
art=Path('unity/Assets/StarTournament/Art')
for kind in ['body','arms']:shutil.copyfile(Path('.local/vector-f8')/f'candidate-{kind}.glb',art/f'trooper-{kind}-animated.glb')
p=art/'asset-manifest.json';d=json.loads(p.read_text())
for e in d['entries']:
 if e.get('key') in ['player-body','player-hands']:e['sha256']=hashlib.sha256((Path('unity')/e['path']).read_bytes()).hexdigest()
p.write_text(json.dumps(d,indent=2)+'\n')
PY
UNITY_RUN_MODE=shared unity/tools.sh editor -batchmode -noaudio -muted -quit -executeMethod StarTournament.ProvingGround.Editor.TrooperPreparation.RefreshExistingScene -logFile "$root/.local/vector-f8/import6.log" > .local/vector-f8/import6-runner.log 2>&1
printf 'FINAL_PALM_IMPORT_DONE\n'
mkdir -p .local/vector-f8/final-assembly
STAR_TOURNAMENT_GRIP_FACTORY=1 STAR_TOURNAMENT_GRIP_MESH=1 STAR_TOURNAMENT_WALK_EVIDENCE="$root/.local/vector-f8/final-assembly" STAR_TOURNAMENT_QA_LAB_HISTORY="$root/.local/vector-f8/final-assembly/history.json" UNITY_RUN_MODE=shared unity/tools.sh editor -batchmode -noaudio -muted -runTests -testPlatform PlayMode -testFilter 'FirstPersonStepsStaySmoothAndIndependentInTheRenderedScene;OrbitalGripDoesNotAccumulateAcrossFrozenSamples' -testResults "$root/.local/vector-f8/final-assembly/results.xml" -logFile "$root/.local/vector-f8/final-assembly/editor.log" > .local/vector-f8/final-assembly/runner.log 2>&1
printf 'FINAL_NATIVE_CHECK_DONE\n'
STAR_TOURNAMENT_QA_LAB_HISTORY="$root/.local/vector-f8/assembly-import-history.json" UNITY_RUN_MODE=shared unity/tools.sh test-edit-filter TrooperImportTests > .local/vector-f8/assembly-import-runner.log 2>&1
printf 'FINAL_IMPORT_CHECK_DONE\n'
