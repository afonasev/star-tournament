import bpy,bmesh
from mathutils import Vector
r=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');o=next(o for o in bpy.context.scene.objects if 'gloves' in o.name)
bm=bmesh.new();bm.from_mesh(o.data);bm.verts.ensure_lookup_table();bm.verts.index_update();left=set(bm.verts);cloth=set()
while left:
 todo=[left.pop()];part=[]
 while todo:
  v=todo.pop();part.append(v)
  for e in v.link_edges:
   n=e.other_vert(v)
   if n in left:left.remove(n);todo.append(n)
 if len(part)>1000:cloth.update(v.index for v in part)
point=Vector((.5991,.0956,1.0343));v=min((v for v in o.data.vertices if v.index in cloth),key=lambda v:((o.matrix_world@v.co)-point).length)
print('NEAREST',v.index,tuple(o.matrix_world@v.co),[(o.vertex_groups[g.group].name,g.weight) for g in v.groups])
# Actual cloth vertices within 8mm of the two back-plate centres.
for p in [Vector((.5991,.0956,1.0343)),Vector((.5982,.0507,1.0351))]:
 ids=[v for v in o.data.vertices if v.index in cloth and ((o.matrix_world@v.co)-p).length<.025];weights={}
 for v in ids:
  for g in v.groups:weights[o.vertex_groups[g.group].name]=weights.get(o.vertex_groups[g.group].name,0)+g.weight/len(ids)
 print('PALM_NEIGHBOURS',len(ids),sorted(weights.items(),key=lambda p:-p[1])[:8])
