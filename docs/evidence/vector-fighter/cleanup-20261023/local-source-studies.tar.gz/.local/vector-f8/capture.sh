#!/bin/sh
set -eu
root=$(pwd)
out="$root/.local/vector-f8/$1"
mkdir -p "$out"
export STAR_TOURNAMENT_GRIP_FACTORY=1 STAR_TOURNAMENT_GRIP_MESH=1
export STAR_TOURNAMENT_GRIP_OVERRIDES="$root/.local/vector-f8/anatomical-fit.txt"
export STAR_TOURNAMENT_WALK_EVIDENCE="$out" STAR_TOURNAMENT_QA_LAB_HISTORY="$out/history.json" UNITY_RUN_MODE=shared
exec unity/tools.sh editor -batchmode -noaudio -muted -runTests -testPlatform PlayMode -testFilter FirstPersonStepsStaySmoothAndIndependentInTheRenderedScene -testResults "$out/results.xml" -logFile "$out/editor.log"
