import bpy,json
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath='scripts/vector_fighter/f14-hand-anatomy.blend')
r=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE')
w=r.data.bones['LeftHand'].head_local;end=sum((r.data.bones['Left'+d+'Proximal'].head_local for d in ['Index','Middle','Ring','Little']),Vector())/4
a=(end-w).normalized();n=Vector((1,0,1)).normalized();n=(n-a*n.dot(a)).normalized();l=n.cross(a).normalized()
d={}
for b in r.data.bones:
 if b.name.startswith('Left') and any(x in b.name for x in ['Hand','Thumb','Index','Middle','Ring','Little']):
  d[b.name]={'head':[round((b.head_local-w).dot(v),5) for v in [a,l,n]],'tail':[round((b.tail_local-w).dot(v),5) for v in [a,l,n]],'length':b.length}
open('.local/vector-f15/bones.json','w').write(json.dumps(d,indent=2))
