from pathlib import Path
p=Path('scripts/vector_fighter/refine_finger_phalanges.py');s=p.read_text().replace('F14:', 'F15:').replace("OUT=ROOT/'.local/vector-f14'","OUT=ROOT/'.local/vector-f15'").replace("f14-hand-anatomy.blend","f15-hand-anatomy.blend")
s=s.replace("capsule(w+axis*(length*.46),bones[0].tail_local,.015,.011)",'''# Broad thenar eminence: the metacarpal is enclosed in the palm,
   # with a rounded triangular transition into the two exposed phalanges.
   # A narrow capsule here creates an apparent third finger segment.
   a=w+axis*(length*.24)+lat*(-.014 if side=='Left' else .014)-n*.003
   b=bones[0].tail_local;da=(b-a).normalized();tn=(n-da*n.dot(da)).normalized();tl=tn.cross(da).normalized()
   loft([(a.lerp(b,t),rx,ry) for t,rx,ry in [
    (0,.024,.016),(.18,.030,.020),(.42,.030,.021),
    (.65,.025,.019),(.82,.018,.014),(1,.012,.011),(1.04,.010,.009)]],da,tn,tl)
   # The first interdigital web joins the index metacarpal to the thumb
   # base, rather than exposing a separate cylindrical thumb stalk.
   index=rig.data.bones[side+'IndexProximal'].head_local
   web_a=w+axis*(length*.58)+lat*(-.024 if side=='Left' else .024)
   web_b=b.lerp(index,.38)-axis*.006
   wd=(web_b-web_a).normalized();wn=(n-wd*n.dot(wd)).normalized();wl=wn.cross(wd).normalized()
   loft([(web_a.lerp(web_b,t),rx,ry) for t,rx,ry in [
    (0,.021,.013),(.35,.024,.013),(.72,.022,.010),(1,.017,.006),(1.08,.008,.002)]],wd,wn,wl)''')
# Increase finger volumes toward MCP, keep the fitted palmar contact surface.
s=s.replace("r=(.016*(1-.25*t) if digit=='Thumb' and j==0 else rr*(1-.11*j))*f", "r=rr*(1-.11*j)*f")
s=s.replace("if digit!='Thumb':fade*=smooth(.65,.90,longitudinal)\n  else:fade*=smooth(.004,.025,lateral*(1 if thumb_lateral>0 else -1))",'''if digit!='Thumb':
   # Keep metacarpals in the palm; allow rotation only around their MCP.
   fade*=smooth(-.012,.008,advance)
  else:
   # Continuous thenar deformation across the palm-to-metacarpal fan.
   radial=lateral*(1 if thumb_lateral>0 else -1)
   fade=smooth(.016,.065,radial)*smooth(.018,.060,(p-w).dot(hand_axis))
   if advance>lengths[0]-.006:fade=1.0''')
s=s.replace('**6 for item in candidates','**3 for item in candidates')
s=s.replace("mod.iterations=5", "mod.iterations=10")
p.write_text(s)
