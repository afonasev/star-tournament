"""F15: rebuild anatomical glove cloth around the unchanged F12 skeleton.
Continuous palm, thenar volume and tapered fingers replace inherited cloth;
existing ceramic layers are retained. Arms/animation stay fixed; the approved
Shotgun palm swell is reduced independently.
"""
import bpy,bmesh,math,json,importlib.util
from pathlib import Path
from mathutils import Vector
ROOT=Path.cwd();OUT=ROOT/'.local/vector-f15';OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'scripts/vector_fighter/f11-fps-forms.blend'))
rig=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');o=bpy.data.objects['VECTOR articulated gloves'];count=len(bpy.context.scene.objects)
# User-approved F14 clearance correction: shrink only the Strata palm swell.
# The attachment, central grip and every other weapon component stay exact.
weapon=bpy.data.objects['weapon:joined'];wb=bmesh.new();wb.from_mesh(weapon.data)
bmesh.ops.remove_doubles(wb,verts=list(wb.verts),dist=.000001);remaining=set(wb.verts);swell=[]
while remaining:
 todo=[remaining.pop()];part=[]
 while todo:
  v=todo.pop();part.append(v)
  for edge in v.link_edges:
   other=edge.other_vert(v)
   if other in remaining:remaining.remove(other);todo.append(other)
 lo=Vector([min(v.co[i] for v in part) for i in range(3)]);hi=Vector([max(v.co[i] for v in part) for i in range(3)])
 if abs((hi-lo).x-.153)<.00001 and abs(lo.z+.295)<.00001:swell.extend(tuple(round(c,6) for c in v.co) for v in part)
wb.free();assert len(swell)==96,'Expected original Strata palm swell only'
swell=set(swell);changed_swell=0
for v in weapon.data.vertices:
 if tuple(round(c,6) for c in v.co) in swell:
  v.co.x=-.0095+(v.co.x+.0095)*(.0455/.153)
  v.co.y=.07+(v.co.y-.07)*(.15/.28);changed_swell+=1
assert changed_swell==115,changed_swell
weapon.data.update()

# The inherited detached stitch strips tear across the reshaped thumb web.
# Replace their raised geometry with the continuous woven cloth surface;
# retain the original source for comparison and all ceramic/chassis details.
seams={i for face in o.data.polygons if 'seam' in o.data.materials[face.material_index].name for i in face.vertices}
bm=bmesh.new();bm.from_mesh(o.data);bm.verts.ensure_lookup_table();bmesh.ops.delete(bm,geom=[v for v in bm.verts if v.index in seams],context='VERTS');bm.to_mesh(o.data);bm.free()
frames={}
for side,sign in [('Left',1),('Right',-1)]:
 wrist=rig.data.bones[side+'Hand'].head_local.copy();end=sum((rig.data.bones[side+d+'Proximal'].head_local for d in ['Index','Middle','Ring','Little']),Vector())/4
 axis=(end-wrist).normalized();normal=Vector((sign,0,1)).normalized();normal=(normal-axis*normal.dot(axis)).normalized();lateral=normal.cross(axis).normalized()
 frames[side]=(wrist,axis,normal,lateral,(end-wrist).length)
def smooth(a,b,x):
 t=max(0,min(1,(x-a)/(b-a)));return t*t*(3-2*t)
changed=0
for v in o.data.vertices:
 p=v.co.copy();side='Left' if p.x>0 else 'Right';w,axis,n,lat,length=frames[side];rel=p-w;t=rel.dot(axis)/length;depth=rel.dot(n)
 # Preserve the seated cuff and knuckle line; reduce the padded spherical palm
 # to a flatter metacarpal volume with a gradual thenar/hypothenar transition.
 palm=smooth(.02,.22,t)*(1-smooth(.72,1.04,t))
 p-=n*depth*.36*palm
 # Taper the palm heel into the unchanged cuff instead of an abrupt bulge.
 heel=smooth(.02,.20,t)*(1-smooth(.32,.72,t))
 p-=lat*rel.dot(lat)*.14*heel
 # Follow the nearest finger chain only after its root web. The palmar contact
 # half stays in place; flatten the dorsal padding, preserving gripping pads.
 chains=[]
 for digit in ['Thumb','Index','Middle','Ring','Little']:
  chain=[rig.data.bones[side+digit+s] for s in ['Proximal','Intermediate','Distal']]
  for b in chain:
   d=b.tail_local-b.head_local;u=max(0,min(1,(v.co-b.head_local).dot(d)/d.length_squared));q=b.head_local+d*u
   chains.append(((v.co-q).length,digit,b,q,d.normalized()))
 _,digit,b,q,d=min(chains,key=lambda item:item[0]);root=rig.data.bones[side+digit+'Proximal'];advance=(v.co-root.head_local).dot((root.tail_local-root.head_local).normalized())
 if advance>0:
  fade=smooth(0,.018,advance);radial=v.co-q;dn=n-d*n.dot(d);dn.normalize();dorsal=radial.dot(dn)
  if dorsal>0:p-=dn*dorsal*.20*fade
  # A less swollen thumb shaft, while retaining its pad and bone positions.
  if digit=='Thumb':p-=(radial-dn*dorsal)*.10*fade
 if (p-v.co).length>1e-7:changed+=1
 v.co=p
o.data.update()
# Replace the inherited folded textile with a closed anatomical volume.
# Keep neutral cloth and participant-colored ceramic material roles.
from mathutils.bvhtree import BVHTree
cloth={i for face in o.data.polygons if o.data.materials[face.material_index].name in ['material.001','vector-glove.001'] for i in face.vertices}
# Author a clean closed hand volume around the existing skeleton. Elliptic
# palm sections define the heel, metacarpals and knuckle row; tapered digit
# capsules merge into that volume before smoothing/skin assignment.
verts=[];faces=[]
def loft(rings,axis,normal,lateral,N=32,power=1):
 start=len(verts)
 for center,rx,ry in rings:
  for i in range(N):
   theta=2*math.pi*i/N;c=math.cos(theta);s=math.sin(theta)
   verts.append(center+lateral*(rx*math.copysign(abs(c)**power,c))+normal*(ry*math.copysign(abs(s)**power,s)))
 faces.append(tuple(reversed([start+i for i in range(N)])))
 for j in range(len(rings)-1):
  for i in range(N):k=start+j*N+i;l=start+j*N+(i+1)%N;faces.append((k,l,l+N,k+N))
 faces.append(tuple(start+(len(rings)-1)*N+i for i in range(N)))
def capsule(a,b,ra,rb):
 axis=(b-a).normalized();n=axis.cross(Vector((0,1,0)))
 if n.length<.01:n=axis.cross(Vector((0,0,1)))
 n.normalize();lat=axis.cross(n);rings=[]
 for theta in [-math.pi/2,-math.pi/3,-math.pi/6,0]:rings.append((a+axis*(ra*math.sin(theta)),max(.0001,ra*math.cos(theta)),max(.0001,ra*math.cos(theta))))
 rings.append((a.lerp(b,.5),(ra+rb)/2,(ra+rb)/2))
 for theta in [0,math.pi/6,math.pi/3,math.pi/2]:rings.append((b+axis*(rb*math.sin(theta)),max(.0001,rb*math.cos(theta)),max(.0001,rb*math.cos(theta))))
 loft(rings,axis,n,lat,24)
for side in ['Left','Right']:
 w,axis,n,lat,length=frames[side]
 # Natural glove heel, flatter palm and broad MCP row, with no detached cuff.
 sections=[(-.03,.029,.029),(0,.030,.028),(.15,.033,.023),(.35,.039,.019),(.60,.043,.017),(.82,.044,.013),(.96,.042,.010),(1.015,.033,.006),(1.035,.012,.003)]
 palm_start=len(verts)
 # A padded palm has rounded rectangular sections; an ellipse collapses at
 # the ulnar edge and exposes the little metacarpal as a separate tube.
 loft([(w+axis*(t*length)-n*.002,rx,ry) for t,rx,ry in sections],axis,n,lat,power=.65)
 knuckles=sorted(((rig.data.bones[side+d+'Proximal'].head_local-w).dot(lat),
                  (rig.data.bones[side+d+'Proximal'].head_local-w).dot(axis)) for d in ['Index','Middle','Ring','Little'])
 for v in verts[palm_start:]:
  t=(v-w).dot(axis)/length;x=(v-w).dot(lat)
  y=knuckles[0][1] if x<knuckles[0][0] else knuckles[-1][1]
  for (x0,y0),(x1,y1) in zip(knuckles,knuckles[1:]):
   if x0<=x<=x1:y=y0+(y1-y0)*(x-x0)/(x1-x0);break
  v+=axis*smooth(.7,1.04,t)*(y-length-.003)
 for digit,rr in [('Thumb',.0115),('Index',.0095),('Middle',.010),('Ring',.0093),('Little',.008)]:
  bones=[rig.data.bones[side+digit+seg] for seg in ['Proximal','Intermediate','Distal']]
  if digit!='Thumb':
   # Rounded metacarpal web overlaps both palm and digit before voxel union;
   # shortening the palm alone would leave capped, disconnected fingers.
   root=bones[0];d=(root.tail_local-root.head_local).normalized()
   capsule(root.head_local-axis*.012,root.head_local+d*.006,rr*1.15,rr)
  if digit=='Thumb':
   # The first thumb bone is a metacarpal inside the thenar eminence,
   # not a third exposed phalanx. Blend it into the palm/web.
   # Broad thenar eminence: the metacarpal is enclosed in the palm,
   # with a rounded triangular transition into the two exposed phalanges.
   # A narrow capsule here creates an apparent third finger segment.
   a=w+axis*(length*.42)+lat*(-.015 if side=='Left' else .015)-n*.005
   b=bones[0].tail_local;da=(b-a).normalized();tn=(n-da*n.dot(da)).normalized();tl=tn.cross(da).normalized()
   loft([(a.lerp(b,t),rx,ry) for t,rx,ry in [
    (0,.024,.013),(.18,.023,.014),(.42,.020,.014),
    (.65,.016,.012),(.82,.013,.011),(1,.012,.010),(1.04,.010,.009)]],da,tn,tl)
  # One continuous digit: near-straight shafts, narrow flexion creases,
  # modest knuckle volume and a flattened pad, not overlapping capsules.
  rings=[]
  for j,bone in enumerate(bones):
   if digit=='Thumb' and j==0:continue # Metacarpal is covered by thenar, not an exposed finger shaft.
   d=bone.tail_local-bone.head_local
   for t,f in [(0,1.0),(.10,.97),(.28,.95),(.62,.92),(.88,.96),(.97,1.0)]:
    if j==2 and t>.70:continue
    r=rr*(1-.11*j)*f
    pad_root=(1-smooth(.02,.45,t)) if j==0 and digit!='Thumb' else 0
    nd=n-d.normalized()*n.dot(d.normalized());nd.normalize()
    rings.append((bone.head_local+d*t+nd*(.0025*pad_root),r,r*(.82-.20*pad_root),d.normalized()))
  d=(bones[-1].tail_local-bones[-1].head_local).normalized();tip=bones[-1].tail_local
  for back,f in [(rr*.65,.90),(rr*.38,.76),(rr*.15,.48),(0,.08)]:rings.append((tip-d*back,rr*.78*f,rr*.64*f,d))
  direction=(bones[-1].tail_local-bones[0].head_local).normalized();dn=n-direction*n.dot(direction);dn.normalize();dl=dn.cross(direction).normalized()
  # Sections follow each phalanx, rather than shearing obliquely to a
  # single overall digit axis. This preserves pads in flexed skinning.
  start=len(verts);N=24
  for center,rx,ry,segment_axis in rings:
   normal=n-segment_axis*n.dot(segment_axis);normal.normalize();lateral=normal.cross(segment_axis).normalized()
   for i in range(N):
    theta=2*math.pi*i/N;verts.append(center+lateral*(rx*math.cos(theta))+normal*(ry*math.sin(theta)))
  faces.append(tuple(reversed([start+i for i in range(N)])))
  for j in range(len(rings)-1):
   for i in range(N):k=start+j*N+i;l=start+j*N+(i+1)%N;faces.append((k,l,l+N,k+N))
  faces.append(tuple(start+(len(rings)-1)*N+i for i in range(N)))
mesh=bpy.data.meshes.new('F14 continuous anatomical glove');mesh.from_pydata(verts,[],faces);mesh.update()
shell=bpy.data.objects.new('F14 anatomical cloth',mesh);bpy.context.collection.objects.link(shell)
for mat in o.data.materials:mesh.materials.append(mat)
bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(mesh);bm.free()
bpy.context.view_layer.objects.active=shell
for mod in list(shell.modifiers):shell.modifiers.remove(mod)
mod=shell.modifiers.new('Continuous anatomical glove surface','REMESH');mod.mode='VOXEL';mod.voxel_size=.00065;mod.use_smooth_shade=True;mod.use_remove_disconnected=False;bpy.ops.object.modifier_apply(modifier=mod.name)
assert len(shell.data.vertices)>10000, 'Voxel shell lost volume: '+str(len(shell.data.vertices))
# Each hand must remain one connected textile surface.
bm=bmesh.new();bm.from_mesh(shell.data);remaining=set(bm.verts);component_sizes=[]
while remaining:
 todo=[remaining.pop()];size=0;points=[]
 while todo:
  v=todo.pop();size+=1;points.append(v.co.copy())
  for edge in v.link_edges:
   other=edge.other_vert(v)
   if other in remaining:remaining.remove(other);todo.append(other)
 component_sizes.append(size)
 center=sum(points,Vector())/len(points);side="Left" if center.x>0 else "Right";w,axis,n,lat,length=frames[side];print("COMPONENT",size,side,[(center-w).dot(v) for v in [axis,lat,n]],flush=True)
bm.free();assert len(component_sizes)==2,('Disconnected glove cloth',component_sizes)
